﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;

namespace EasyUIDemo.DBUtility
{
    /// <summary>
    /// 枚举信息
    /// </summary>
    public class EnumHelper
    {
        #region 枚举
        /// <summary>
        /// 查询提示
        /// </summary>
        public enum SearchTip
        {
            [Description("正常(0)")]
            正常 = 0,
            [Description("失败(-1000)")]
            失败 = -1000,
            [Description("账户不存在(-1001)")]
            账户不存在 = -1001,
            [Description("账户已存在(-1002)")]
            账户已存在 = -1002,
            [Description("操作员账号已失效(-1021)")]
            操作员账号已失效 = -1021,
            [Description("操作员账号操作权限不够(-1022)")]
            操作员账号操作权限不够 = -1022,
            [Description("输入参数有误(-2001)")]
            输入参数有误 = -2001,
            [Description("店主账号已经有其他身份(-1052)")]
            店主账号已经有其他身份=-1052,
            [Description("缺少会员组织关系数据(-1045)")]
            缺少会员组织关系数据= -1045,
            [Description("该账号还未激活加盟店或代理商(-1044)")]
            该账号还未激活加盟店或代理商 = -1044,
            [Description("没有操作此加盟店账号的权限(-1060)")]
            没有操作此加盟店账号的权限= -1060,
            [Description("操作员账号操作权限不够(-1062)")]
            操作员账号操作权限不够1062 = -1062,
            [Description("操作员账号已失效(-1061)")]
            操作员账号已失效1061 = -1061,
            [Description("手机号码已被绑定(-2006)")]
            手机号码已被绑定 = -2006,
            [Description("执行异常(-1)")]
            执行异常 = -1,
            [Description("执行异常(9999)")]
            执行异常9999 = 9999
        }

        /// <summary>
        /// 注册提示
        /// </summary>
        public enum AddTip
        {
            [Description("添加成功(0)")]
            添加成功 = 0,
            [Description("添加失败(-1000)")]
            添加失败 = -1000,
            [Description("账户不存在(-1001)")]
            账户不存在 = -1001,
            [Description("账户已存在(-1002)")]
            账户已存在 = -1002,
            [Description("操作员账号已失效(-1021)")]
            操作员账号已失效 = -1021,
            [Description("操作员账号操作权限不够(-1022)")]
            操作员账号操作权限不够 = -1022,
            [Description("输入参数有误(-2001)")]
            输入参数有误 = -2001,
            [Description("部门编号已存在(-1046)")]
            部门编号已存在 = -1046,
            [Description("该账号还未激活加盟店或代理商(-1044)")]
            该账号还未激活加盟店或代理商 = -1044,
            [Description("没有操作权限(-1013)")]
            没有操作权限 = -1013,
            [Description("缺少会员组织关系数据(-1045)")]
            缺少会员组织关系数据 = -1045,
            [Description("没有操作此加盟店账号的权限(-1020)")]
            没有操作此加盟店账号的权限 = -1020,
            [Description("有待审核的申请记录未处理(-1049)")]
            有待审核的申请记录未处理 = -1049,
            [Description("插入失败(-3001)")]
            插入失败 = -3001,
            [Description("店主账号已经有其他身份(-1052)")]
            店主账号已经有其他身份 = -1052,
            [Description("手机号码已被绑定(-2006)")]
            手机号码已被绑定 = -2006,
            [Description("没有操作此加盟店账号的权限(-1060)")]
            没有操作此加盟店账号的权限1060 = -1060,
            [Description("操作员账号操作权限不够(-1062)")]
            操作员账号操作权限不够1062 = -1062,
            [Description("操作员账号已失效(-1061)")]
            操作员账号已失效1061 = -1061,
            [Description("数据异常(-3005)")]
            数据异常 = -3005,
            [Description("店主账号按辅导关系往上找没有找到市场部节点会员(-1054)")]
            店主账号按辅导关系往上找没有找到市场部节点会员 = -1054,
            [Description("登录账号已经有其他身份(-1053)")]
            登录账号已经有其他身份 = -1053,
            [Description("部门名称已存在(-1067)")]
            部门名称已存在= -1067,
            [Description("登录账号已存在(-1069)")]
            登录账号已存在 = -1069,
            [Description("执行异常(-1)")]
            执行异常 = -1,
            [Description("执行异常(9999)")]
            执行异常9999 = 9999
        }

        /// <summary>
        /// 修改提示
        /// </summary>
        public enum EditTip
        {
            [Description("保存成功(0)")]
            保存成功 = 0,
            [Description("保存失败(-1000)")]
            保存失败 = -1000,
            [Description("账户不存在(-1001)")]
            账户不存在 = -1001,
            [Description("账户已存在(-1002)")]
            账户已存在 = -1002,
            [Description("操作员账号已失效(-1021)")]
            操作员账号已失效 = -1021,
            [Description("操作员账号操作权限不够(-1022)")]
            操作员账号操作权限不够 = -1022,
            [Description("输入参数有误(-2001)")]
            输入参数有误 = -2001,
            [Description("部门编号已存在(-1046)")]
            部门编号已存在 = -1046,
            [Description("该账号还未激活加盟店或代理商(-1044)")]
            该账号还未激活加盟店或代理商 = -1044,
            [Description("缺少会员组织关系数据(-1045)")]
            缺少会员组织关系数据 = -1045,
            [Description("没有操作此加盟店账号的权限(-1020)")]
            没有操作此加盟店账号的权限 = -1020,
            [Description("有待审核的申请记录未处理(-1049)")]
            有待审核的申请记录未处理 = -1049,
            [Description("插入失败(-3001)")]
            插入失败 = -3001,
            [Description("店主账号已经有其他身份(-1052)")]
            店主账号已经有其他身份 = -1052,
            [Description("手机号码已被绑定(-2006)")]
            手机号码已被绑定 = -2006,
            [Description("数据异常(-3005)")]
            数据异常= -3005,
            [Description("店主账号按辅导关系往上找没有找到市场部节点会员(-1054)")]
            店主账号按辅导关系往上找没有找到市场部节点会员= -1054,
            [Description("登录账号已经有其他身份(-1053)")]
            登录账号已经有其他身份 = -1053,
            [Description("没有操作此加盟店账号的权限(-1060)")]
            没有操作此加盟店账号的权限1060 = -1060,
            [Description("部门名称已存在(-1067)")]
            部门名称已存在 = -1067,
            [Description("登录账号已存在(-1069)")]
            登录账号已存在 = -1069,
            [Description("修改的点数超过最大值(-1051)")]
            修改的点数超过最大值=-1051,
            [Description("执行异常(-1)")]
            执行异常 = -1,
            [Description("执行异常(9999)")]
            执行异常9999 = 9999
        }

        /// <summary>
        /// 审核提示
        /// </summary>
        public enum ReviewTip
        {
            [Description("审核成功(-1000)")]
            审核成功 = 0,
            [Description("审核失败(-1000)")]
            审核失败 = -1000,
            [Description("账户不存在(-1001)")]
            账户不存在 = -1001,
            [Description("账户已存在(-1002)")]
            账户已存在 = -1002,
            [Description("操作员账号已失效(-1021)")]
            操作员账号已失效 = -1021,
            [Description("操作员账号操作权限不够(-1022)")]
            操作员账号操作权限不够 = -1022,
            [Description("输入参数有误(-2001)")]
            输入参数有误 = -2001,
            [Description("部门编号已存在(-1046)")]
            部门编号已存在 = -1046,
            [Description("该账号还未激活加盟店或代理商(-1044)")]
            该账号还未激活加盟店或代理商 = -1044,
            [Description("缺少会员组织关系数据(-1045)")]
            缺少会员组织关系数据 = -1045,
            [Description("没有操作此加盟店账号的权限(-1020)")]
            没有操作此加盟店账号的权限 = -1020,
            [Description("有待审核的申请记录未处理(-1049)")]
            有待审核的申请记录未处理 = -1049,
            [Description("插入失败(-3001)")]
            插入失败 = -3001,
            [Description("状态异常(-3006)")]
            状态异常 = -3006,
            [Description("修改的点数超过最大值(-1051)")]
            修改的点数超过最大值 = -1051,
            [Description("当前账户的点数和申请时候的点数有变化(-1050)")]
            当前账户的点数和申请时候的点数有变化 = -1050,
            [Description("申请项目已被审核(-1065)")]
            申请项目已被审核 = -1065,
            [Description("没有该申请项目(-1066)")]
            没有该申请项目 = -1066,
            [Description("执行异常(-1)")]
            执行异常 = -1,
            [Description("执行异常(9999)")]
            执行异常9999 = 9999
        }

        /// <summary>
        /// 审核退回提示
        /// </summary>
        public enum BackTip
        {
            [Description("审核成功(0)")]
            审核成功 = 0,
            [Description("审核失败(-1000)")]
            审核失败 = -1000,
            [Description("账户不存在(-1001)")]
            账户不存在 = -1001,
            [Description("账户已存在(-1002)")]
            账户已存在 = -1002,
            [Description("操作员账号已失效(-1021)")]
            操作员账号已失效 = -1021,
            [Description("操作员账号操作权限不够(-1022)")]
            操作员账号操作权限不够 = -1022,
            [Description("输入参数有误(-2001)")]
            输入参数有误 = -2001,
            [Description("部门编号已存在(-1046)")]
            部门编号已存在 = -1046,
            [Description("该账号还未激活加盟店或代理商(-1044)")]
            该账号还未激活加盟店或代理商 = -1044,
            [Description("缺少会员组织关系数据(-1045)")]
            缺少会员组织关系数据 = -1045,
            [Description("没有操作此加盟店账号的权限(-1020)")]
            没有操作此加盟店账号的权限 = -1020,
            [Description("有待审核的申请记录未处理(-1049)")]
            有待审核的申请记录未处理 = -1049,
            [Description("插入失败(-3001)")]
            插入失败 = -3001,
            [Description("状态异常(-3006)")]
            状态异常 = -3006,
            [Description("修改的点数超过最大值(-1051)")]
            修改的点数超过最大值 = -1051,
            [Description("当前账户的点数和申请时候的点数有变化(-1050)")]
            当前账户的点数和申请时候的点数有变化 = -1050,
            [Description("执行异常(-1)")]
            执行异常 = -1,
            [Description("执行异常(9999)")]
            执行异常9999 = 9999
        }

        /// <summary>
        /// 日志类型
        /// </summary>
        public enum MarktLogType
        {
            [Description("登录日志")]
            登录日志 = 1,
            [Description("异常日志")]
            异常日志 = 2,
            [Description("操作日志")]
            操作日志 = 3,
            [Description("数据日志")]
            数据日志 = 4
        }


        #endregion
    }

    #region 枚举 扩展
    /// <summary>
    /// 枚举 扩展
    /// </summary>
    public static class EnumExtension
    {
        /// <summary>
        /// 把集合转成DataTable
        /// </summary>
        public static DataTable EnumToDataTable<T>(this IEnumerable<T> enumerable)
        {
            var dataTable = new DataTable();
            foreach (PropertyDescriptor pd in TypeDescriptor.GetProperties(typeof(T)))
            {
                dataTable.Columns.Add(pd.Name, pd.PropertyType);
            }
            foreach (T item in enumerable)
            {
                var Row = dataTable.NewRow();

                foreach (PropertyDescriptor dp in TypeDescriptor.GetProperties(typeof(T)))
                {
                    Row[dp.Name] = dp.GetValue(item);
                }
                dataTable.Rows.Add(Row);
            }
            return dataTable;
        }

        /// <summary>
        /// 枚举转字典
        /// </summary>
        /// <param name="enumType"></param>
        /// <returns></returns>
        public static Dictionary<string, string> EnumToDictionary(this Type enumType)
        {
            Dictionary<string, string> list = new Dictionary<string, string>();
            foreach (int i in Enum.GetValues(enumType))
            {
                list.Add(i.ToString(), Enum.GetName(enumType, i));
            }
            return list;
        }

        /// <summary>
        /// 获取枚举描述
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string GetDescription(this Enum value)
        {
            System.Reflection.FieldInfo field = value.GetType().GetField(value.ToString());

            System.ComponentModel.DescriptionAttribute attribute = Attribute.GetCustomAttribute(field, typeof(System.ComponentModel.DescriptionAttribute)) as System.ComponentModel.DescriptionAttribute;

            return attribute == null ? value.ToString() : attribute.Description;
        }

        public static T EnumParse<T>(string value) where T : struct
        {
            return EnumParse<T>(value, false);
        }

        public static T EnumParse<T>(string value, bool ignoreCase) where T : struct
        {
            if (!typeof(T).IsEnum)
            {
                throw new ArgumentException("T must be an enum type.");
            }

            var result = (T)Enum.Parse(typeof(T), value, ignoreCase);
            return result;
        }

        public static T ToEnum<T>(this string value) where T : struct
        {
            return EnumParse<T>(value);
        }

        public static T ToEnum<T>(this string value, bool ignoreCase) where T : struct
        {
            return EnumParse<T>(value, ignoreCase);
        }
    }
    #endregion
}
