﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace EasyUIDemo.DBUtility
{
    /// <summary>
    /// 简单的SQL防注入类
    /// </summary>
    public class SqlInjection
    {
        //防SQL注入正则表达式1
        private static Regex _sqlkeywordregex1 = new Regex(@"(select|insert|delete|from|count\(|drop|table|update|truncate|asc\(|mid\(|char\(|xp_cmdshell|exec|master|net|local|group|administrators|user|or|and)", RegexOptions.IgnoreCase);
        //防SQL注入正则表达式2
        private static Regex _sqlkeywordregex2 = new Regex(@"(select|insert|delete|from|count\(|drop|table|update|truncate|asc\(|mid\(|char\(|xp_cmdshell|exec|master|net|local|group|administrators|user|or|and|-|;|,|\(|\)|\[|\]|\{|\}|%|@|\*|!|\')", RegexOptions.IgnoreCase);

        /// <summary>
        /// 关键字过滤
        /// </summary>
        /// <param name="originalString">原始串</param>
        /// <returns>返回True就是找到了可能sql注入的关键字</returns>
        public static bool GetString(string originalString)
        {
            if (!string.IsNullOrWhiteSpace(originalString))
            {
                //参考：technet.microsoft.com/zh-cn/library/ms161953.aspx
                if (originalString.IndexOf(";") != -1 || originalString.IndexOf("'") != -1 || originalString.IndexOf("--") != -1 || originalString.IndexOf("/*") != -1 || originalString.IndexOf("*/") != -1 || originalString.IndexOf("xp_cmdshell") != -1)
                    return true;
                else
                    return false;
            }
            return true;
        }


        public static bool IsSafeSqlString(string s)
        {
            return IsSafeSqlString(s, true);
        }

        /// <returns></returns>
        public static bool IsSafeSqlString(string s, bool isStrict)
        {
            if (s != null)
            {
                if (isStrict)
                    return !_sqlkeywordregex2.IsMatch(s);
                else
                    return !_sqlkeywordregex1.IsMatch(s);
            }
            return true;
        }
    }
}
