﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Linq;
using System.Text;
using System.Web;
using System.Text.RegularExpressions;
using System.Reflection;
using System.IO;
using Newtonsoft.Json.Converters;

namespace EasyUIDemo.DBUtility
{
    /// <summary>
    /// 数据类型 扩展
    /// </summary>
    public static class ExtensionObject
    {
        public static string ToStringExtension(this object obj)
        {
            string result = string.Empty;
            if (obj != null)
                result = obj.ToString();
            return result;
        }
    }

    public class Comm
    {
        public const string MSG_TRANSFER = "对不起，跨部门转账暂不受理！(直推客户激活不受限制，详情请咨询公司客服)";
        
        /// <summary>
        ///获取IP地址
        /// </summary>
        /// <param name="Str"></param>
        /// <returns></returns>
        public static string GetClientIP
        {
            get
            {
                System.Web.HttpRequest req = System.Web.HttpContext.Current.Request;
                string loginip = req.UserHostAddress;
                //Request.ServerVariables[""]--获取服务变量集合  
                if (req.Headers["Cdn-Src-Ip"] != null) //读取CDN源服务器IP地址
                {
                    loginip = req.Headers["Cdn-Src-Ip"].ToStringExtension();
                }
                else
                {
                    //判断登记用户是否使用设置代理  
                    if (req.ServerVariables["HTTP_X_FORWARDED_FOR"] != null)
                    {
                        //获取代理的服务器Ip地址  
                        loginip = req.ServerVariables["HTTP_X_FORWARDED_FOR"].ToStringExtension();
                    }
                    else
                    {
                        if (req.ServerVariables["REMOTE_ADDR"] != null) //判断发出请求的远程主机的ip地址是否为空  
                        {
                            //获取发出请求的远程主机的Ip地址  
                            loginip = req.ServerVariables["REMOTE_ADDR"].ToStringExtension();
                        }
                    }
                }
                return loginip;
            }
        }

        public static string DataToJson(object obj)
        {
            try
            {
                IsoDateTimeConverter timeFormat = new IsoDateTimeConverter();
                timeFormat.DateTimeFormat = "yyyy-MM-dd HH:mm:ss";
                return Newtonsoft.Json.JsonConvert.SerializeObject(obj, timeFormat);
            }catch(Exception ex)
            {
                return "";
            }
        }

        public static long GuidToLongID()
        {
            byte[] buffer = Guid.NewGuid().ToByteArray();
            return BitConverter.ToInt64(buffer, 0);
        }

        /// <summary>  
        /// 根据GUID获取16位的唯一字符串  
        /// </summary>  
        /// <param name=\"guid\"></param>  
        /// <returns></returns>  
        public static string GuidTo16String()
        {
            long i = 1;
            foreach (byte b in Guid.NewGuid().ToByteArray())
                i *= ((int)b + 1);

            string value = string.Format("{0:x}", i - DateTime.Now.Ticks);
            if (value.Length < 16)
                value = value + GenerateRandomNumber(16 - value.Length);

            return value;
        }

        /// <summary>
        /// 输出操作按钮
        /// </summary>
        /// <param name="dt">根据用户id和菜单标识码得到的用户可以操作的此菜单下的按钮集合</param>
        /// <param name="pageName">当前页面名称，方便拼接js函数名</param>
        public static string GetToolBar(DataTable dt, string pageName)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("{\"toolbar\":[");
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                switch (dt.Rows[i]["Code"].ToString())
                {
                    case "add":
                        sb.Append("{\"text\": \"" + dt.Rows[i]["Name"] + "\",\"iconCls\":\"" + dt.Rows[i]["Icon"] + "\",\"handler\":\"Add" + pageName + "();\"},");
                        break;
                    case "edit":
                        sb.Append("{\"text\": \"" + dt.Rows[i]["Name"] + "\",\"iconCls\":\"" + dt.Rows[i]["Icon"] + "\",\"handler\":\"Edit" + pageName + "();\"},");
                        break;
                    case "delete":
                        sb.Append("{\"text\": \"" + dt.Rows[i]["Name"] + "\",\"iconCls\":\"" + dt.Rows[i]["Icon"] + "\",\"handler\":\"Del" + pageName + "();\"},");
                        break;
                    case "setuserrole":
                        sb.Append("{\"text\": \"" + dt.Rows[i]["Name"] + "\",\"iconCls\":\"" + dt.Rows[i]["Icon"] + "\",\"handler\":\"SetUserRole();\"},");
                        break;
                    case "setuserdept":
                        sb.Append("{\"text\": \"" + dt.Rows[i]["Name"] + "\",\"iconCls\":\"" + dt.Rows[i]["Icon"] + "\",\"handler\":\"SetUserDept();\"},");
                        break;
                    case "roleauthorize":
                        sb.Append("{\"text\": \"" + dt.Rows[i]["Name"] + "\",\"iconCls\":\"" + dt.Rows[i]["Icon"] + "\",\"handler\":\"RoleAuthorize();\"},");
                        break;
                    case "export":
                        sb.Append("{\"text\": \"" + dt.Rows[i]["Name"] + "\",\"iconCls\":\"" + dt.Rows[i]["Icon"] + "\",\"handler\":\"" + pageName + "Export();\"},");
                        break;
                    case "import":
                        sb.Append("{\"text\": \"" + dt.Rows[i]["Name"] + "\",\"iconCls\":\"" + dt.Rows[i]["Icon"] + "\",\"handler\":\"" + pageName + "Import();\"},");
                        break;
                    case "setmenubutton":
                        sb.Append("{\"text\": \"" + dt.Rows[i]["Name"] + "\",\"iconCls\":\"" + dt.Rows[i]["Icon"] + "\",\"handler\":\"SetMenuButton();\"},");
                        break;
                    case "expandall":
                        sb.Append("{\"text\": \"" + dt.Rows[i]["Name"] + "\",\"iconCls\":\"" + dt.Rows[i]["Icon"] + "\",\"handler\":\"" + pageName + "Expandall();\"},");
                        break;
                    case "collapseall":
                        sb.Append("{\"text\": \"" + dt.Rows[i]["Name"] + "\",\"iconCls\":\"" + dt.Rows[i]["Icon"] + "\",\"handler\":\"" + pageName + "Collapseall();\"},");
                        break;
                    case "seltabdata":
                        sb.Append("{\"text\": \"" + dt.Rows[i]["Name"] + "\",\"iconCls\":\"" + dt.Rows[i]["Icon"] + "\",\"handler\":\"SelTabData();\"},");
                        break;
                    case "viporderbackcheck":
                        sb.Append("{\"text\": \"" + dt.Rows[i]["Name"] + "\",\"iconCls\":\"" + dt.Rows[i]["Icon"] + "\",\"handler\":\"Check" + pageName + "();\"},");
                        break;
                    case "viporderbackcheck2":
                        sb.Append("{\"text\": \"" + dt.Rows[i]["Name"] + "\",\"iconCls\":\"" + dt.Rows[i]["Icon"] + "\",\"handler\":\"Refuse" + pageName + "();\"},");
                        break;
                    case "review":
                        sb.Append("{\"text\": \"" + dt.Rows[i]["Name"] + "\",\"iconCls\":\"" + dt.Rows[i]["Icon"] + "\",\"handler\":\"Review" + pageName + "();\"},");
                        break;
                    case "back":
                        sb.Append("{\"text\": \"" + dt.Rows[i]["Name"] + "\",\"iconCls\":\"" + dt.Rows[i]["Icon"] + "\",\"handler\":\"Back" + pageName + "();\"},");
                        break;
                    case "unfrozen":
                        sb.Append("{\"text\": \"" + dt.Rows[i]["Name"] + "\",\"iconCls\":\"" + dt.Rows[i]["Icon"] + "\",\"handler\":\"unfrozen" + pageName + "();\"},");
                        break;
                    case "checkrefuse":
                        sb.Append("{\"text\": \"" + dt.Rows[i]["Name"] + "\",\"iconCls\":\"" + dt.Rows[i]["Icon"] + "\",\"handler\":\"checkrefuse" + pageName + "();\"},");
                        break;
                    case "checkadopt":
                        sb.Append("{\"text\": \"" + dt.Rows[i]["Name"] + "\",\"iconCls\":\"" + dt.Rows[i]["Icon"] + "\",\"handler\":\"checkadopt" + pageName + "();\"},");
                        break;
                    case "checkIssued":
                        sb.Append("{\"text\": \"" + dt.Rows[i]["Name"] + "\",\"iconCls\":\"" + dt.Rows[i]["Icon"] + "\",\"handler\":\"checkIssued" + pageName + "();\"},");
                        break;
                    case "IssuedFailureBack":
                        sb.Append("{\"text\": \"" + dt.Rows[i]["Name"] + "\",\"iconCls\":\"" + dt.Rows[i]["Icon"] + "\",\"handler\":\"IssuedFailureBack" + pageName + "();\"},");
                        break;
                    default:
                        //browser不是按钮
                        break;
                }
            }

            bool flag = true;   //是否有浏览权限
            DataRow[] row = dt.Select("code = 'search'");
            if (row.Length == 0)  //没有浏览权限
            {
                flag = false;
                if (dt.Rows.Count > 0)
                    sb.Remove(sb.Length - 1, 1);
            }
            else
            {
                if (dt.Rows.Count > 1)
                    sb.Remove(sb.Length - 1, 1);
            }
            sb.Append("],\"success\":true,");
            if (flag)
                sb.Append("\"search\":true}");
            else
                sb.Append("\"search\":false}");

            return sb.ToString();
        }

        /// <summary>
        /// 获取客户端的IP地址
        /// </summary>
        /// <returns>客户端IP地址</returns>
        public static string Get_ClientIP()
        {
            string result = string.Empty;
            result = HttpContext.Current.Request.Headers["X-Real-IP"]; //Nginx 为前端时获取IP地址的方法
            if (result != null)
                return result;

            if (HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"] != null)//发出请求的远程主机的IP地址
            {
                result = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"].ToString();
            }
            else if (HttpContext.Current.Request.ServerVariables["HTTP_VIA"] != null)//判断是否设置代理，若使用了代理
            {
                if (HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"] != null)//获取代理服务器的IP
                {
                    result = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"].ToString();
                }
                else
                {
                    result = HttpContext.Current.Request.UserHostAddress;
                }
            }
            else
            {
                result = HttpContext.Current.Request.UserHostAddress;
            }
            if (result == "::1")
                result = string.Empty;
            return result;
        }

        /// <summary>
        /// 判断dataset是否为空，datatable里面是否有数据
        /// </summary>
        /// <param name="ds"></param>
        /// <returns></returns>
        public static bool ExistsDataSet(DataSet ds)
        {
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                return true;
            }
            return false;
        }

        public static string CreatePhoneValiCode()
        {
            return new Random().Next(100000, 999999).ToString().PadLeft(6, '0');
        }

        public static string EncryptionEmailOrPhoneOrCarId(string str, int type)
        {
            string result = string.Empty;
            if (!string.IsNullOrEmpty(str))
            {
                switch (type)
                {
                    case 1://加密手机号码
                        if (str.Length == 11)
                            result = str.Substring(0, 3) + "****" + str.Substring(7, 4);
                        else
                            result = str.Substring(0, 2) + "***";
                        break;
                    case 2://加密邮箱
                        int at = str.IndexOf("@");
                        result = str.Substring(0, 3) + "****" + str.Substring(at, str.Length - at);
                        break;
                    case 3://加密身份证
                        if (str.Length == 15)
                            result = str.Substring(0, 3) + "****" + str.Substring(12, 3);
                        else if (str.Length == 18)
                            result = str.Substring(0, 3) + "****" + str.Substring(15, 3);
                        break;
                    default:
                        if (str.Length < 11 && str.Length > 2)
                            result = str.Substring(0, 2) + "***";
                        break;
                }
            }

            return result;
        }

        /// <summary>
        /// 动态创建数据表 固定字段 Id, CreateTime,CreateBy,UpdateTime,UpdateBy
        /// </summary>
        /// <returns></returns>
        public static bool CreateTable(string tabName)
        {
            bool res = false;
            try
            {
                SqlParameter[] parameters = {
                    new SqlParameter("@TabName", SqlDbType.NVarChar,50)
                };
                parameters[0].Value = tabName;
                SqlHelper.ExecuteNonQuery(SqlHelper.connStr, CommandType.StoredProcedure, "sp_CreateTable", parameters);
                res = true;
            }
            catch (Exception ex)
            {
                res = false;
            }
            return res;
        }

        /// <summary>
        /// 动态创建数据表 固定字段 Id, CreateTime,CreateBy,UpdateTime,UpdateBy
        /// </summary>
        /// <returns></returns>
        public static bool DropTable(string tabName)
        {
            bool res = false;
            try
            {
                string sql = "DROP TABLE " + tabName;
                SqlHelper.ExecuteNonQuery(SqlHelper.connStr, CommandType.Text, sql, null);
                res = true;
            }
            catch (Exception ex)
            {
                res = false;
            }
            return res;
        }

        /// <summary>
        /// 动态添加数据库字段 
        /// </summary>
        /// <returns></returns>
        public static bool AddTabField(string tabName, string fieldName, string dataType)
        {
            bool res = false;
            try
            {
                string sql = " ALTER TABLE " + tabName + " ADD " + fieldName + " " + dataType + " NULL ";
                SqlHelper.ExecuteNonQuery(SqlHelper.connStr, CommandType.Text, sql, null);
                res = true;
            }
            catch (Exception ex)
            {
                res = false;
            }
            return res;
        }

        /// <summary>
        /// 动态更新数据库字段类型
        /// </summary>
        /// <returns></returns>
        public static bool UpdateTabField(string tabName, string fieldName, string dataType)
        {
            bool res = false;
            try
            {
                string sql = " ALTER TABLE " + tabName + " ALTER COLUMN " + fieldName + " " + dataType + " NULL ";
                SqlHelper.ExecuteNonQuery(SqlHelper.connStr, CommandType.Text, sql, null);
                res = true;
            }
            catch (Exception ex)
            {
                res = false;
            }
            return res;
        }


        /// <summary>
        /// 动态删除数据库字段
        /// </summary>
        /// <returns></returns>
        public static bool DelTabField(string tabName, string fieldName)
        {
            bool res = false;
            try
            {
                string sql = " ALTER TABLE " + tabName + " DROP COLUMN " + fieldName;
                SqlHelper.ExecuteNonQuery(SqlHelper.connStr, CommandType.Text, sql, null);
                res = true;
            }
            catch (Exception ex)
            {
                res = false;
            }
            return res;
        }

        /// <summary>
        /// 获取列Json
        /// </summary>
        /// <param name="TabId"></param>
        /// <returns></returns>
        public static string GetColumnsJsonStr(int TabId)
        {
            string fieldJson = "{\"columns\":[[{\"field\":\"Id\",\"title\":\"主键\",\"width\":\"40\"},";
            string sql = "SELECT Id,FieldName,FieldViewName FROM tbFields WHERE TabId=@TabId";
            SqlParameter[] paras = {
                                   new SqlParameter("@TabId",SqlDbType.Int)
                                   };
            paras[0].Value = TabId;
            DataTable dtFields = SqlHelper.GetDataTable(SqlHelper.connStr, CommandType.Text, sql, paras);
            if (dtFields.Rows.Count > 0)
            {
                foreach (DataRow dr in dtFields.Rows)
                {
                    fieldJson += "{\"field\":\"" + dr["FieldName"].ToString() + "\",\"title\":\"" + dr["FieldViewName"].ToString() + "\",\"width\":\"100\"},";
                }
            }
            fieldJson += "{\"field\":\"CreateBy\",\"title\":\"创建人\",\"width\":\"80\"},";
            fieldJson += "{\"field\":\"CreateTime\",\"title\":\"创建时间\",\"width\":\"130\"},";
            fieldJson += "{\"field\":\"UpdateBy\",\"title\":\"最后更新人\",\"width\":\"80\"},";
            fieldJson += "{\"field\":\"UpdateTime\",\"title\":\"最后更新时间\",\"width\":\"130\"}";
            fieldJson += "]]}";
            return fieldJson;
        }

        /// <summary>
        /// 获取列名字符串 用于查询
        /// </summary>
        /// <param name="TabId"></param>
        /// <returns></returns>
        public static string GetColumnsStr(int TabId)
        {
            string cols = "Id,CreateBy,CreateTime,UpdateBy,UpdateTime,";
            string sql = "SELECT Id,FieldName,FieldViewName FROM tbFields WHERE TabId=@TabId";
            SqlParameter[] paras = {
                                   new SqlParameter("@TabId",SqlDbType.Int)
                                   };
            paras[0].Value = TabId;
            DataTable dtFields = SqlHelper.GetDataTable(SqlHelper.connStr, CommandType.Text, sql, paras);
            if (dtFields.Rows.Count > 0)
            {
                foreach (DataRow dr in dtFields.Rows)
                {
                    cols += dr["FieldName"].ToString() + ",";
                }
            }
            cols = cols.TrimEnd(',');
            return cols;
        }

        /// <summary>
        /// 市场管理查询加盟店账号
        /// </summary>
        /// <param name="paras"></param>
        /// <param name="tablename"></param>
        /// <returns></returns>
        public static DataSet GetManagmentInfoByAccount(SqlParameter[] paras, string tablename)
        {
            DataSet ds = null;
            ds = SqlHelper.RunProcedure("proc_ZKA_ht_managment_relation_query", paras, tablename);
            return ds;
        }

        public static string CurrenTimeUnix()
        {
            System.DateTime startTime = TimeZone.CurrentTimeZone.ToLocalTime(new System.DateTime(1970, 1, 1)); // 当地时区
            long timeStamp = (long)(DateTime.Now - startTime).TotalMilliseconds; // 相差毫秒数
            return timeStamp.ToString();
        }



        /// <summary>
        /// 时间戳转为C#格式时间
        /// </summary>
        /// <param name="timeStamp">Unix时间戳格式</param>
        /// <returns></returns>
        public static DateTime GetTime(string timeStamp)
        {
            DateTime dtStart = TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1));
            long lTime = long.Parse(timeStamp + "0000000");
            TimeSpan toNow = new TimeSpan(lTime);
            return dtStart.Add(toNow);
        }

        /// <summary>
        /// DateTime时间格式转换为Unix时间戳格式
        /// </summary>
        /// <param name="time"> DateTime时间格式</param>
        /// <returns>Unix时间戳格式</returns>
        public static int ConvertDateTimeInt(System.DateTime time)
        {
            System.DateTime startTime = TimeZone.CurrentTimeZone.ToLocalTime(new System.DateTime(1970, 1, 1));
            return Convert.ToInt32((time - startTime).TotalSeconds);
        }



        /// <summary>
        /// 签名
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="secretkey"></param>
        /// <returns></returns>
        public static string make_signature(Dictionary<string, object> obj, string secretkey = "xinhan2015")
        {
            obj.Add("secretkey", secretkey);

            Dictionary<string, object> sign = obj.OrderBy(o => o.Key).ToDictionary(o => o.Key, p => p.Value);

            if (sign.Count < 2)
            {
                obj.Remove("secretkey");
                return (MD5(sign.Values.First().ToString()));
            }
            else
            {
                string outwords = null;
                //foreach (String value in sign.Values)
                //{
                //    outwords += value + ",";
                //}

                foreach (KeyValuePair<string, object> kv in sign)
                {
                    outwords += kv.Key + "," + kv.Value.ToString() + ",";
                }

                MD5CryptoServiceProvider hashmd5;
                hashmd5 = new MD5CryptoServiceProvider();
                obj.Remove("secretkey");
                //return BitConverter.ToString(hashmd5.ComputeHash(Encoding.Default.GetBytes(outwords.Substring(0, outwords.Length - 1)))).Replace("-", "");
                //return (MD5(outwords.Substring(0, outwords.Length - 1)));
                return System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(outwords.Substring(0, outwords.Length - 1), "md5").ToUpper();
            }
        }

        /// <summary>
        /// MD5字符串加密
        /// </summary>
        /// <param name="str">需加密字符串</param>
        /// <returns></returns>
        public static string MD5(string str)
        {
            MD5 md5 = new MD5CryptoServiceProvider();
            byte[] result = md5.ComputeHash(System.Text.Encoding.Default.GetBytes(str));
            StringBuilder newStr = new StringBuilder();
            for (int i = 0; i < result.Length; i++)
            {
                newStr.AppendFormat("{0:X2}", result[i]);
            }
            return newStr.ToString();
        }


        /// <summary>
        /// 按字段key排序
        /// </summary>
        /// <param name="dic">字段</param>
        /// <param name="tag">-1倒序;其他正序</param>
        /// <returns></returns>
        /// <remarks></remarks>
        public static Dictionary<string, string> DictonarySort(Dictionary<string, string> dic, int tag)
        {
            //Dim dic_result As Dictionary(Of String, String) = New Dictionary(Of String, String)()
            //Dim dicSort
            //If tag = -1 Then
            //    dicSort = From objDic In dic Order By objDic.Key Descending Select objDic
            //Else
            //    dicSort = From objDic In dic Order By objDic.Key Select objDic
            //End If

            //For Each kvp As KeyValuePair(Of String, String) In dicSort
            //    dic_result.Add(kvp.Key, kvp.Value)
            //Next

            //Return dic_result


            Dictionary<string, string> dic_result = new Dictionary<string, string>();
            List<KeyValuePair<string, string>> dicSort;
            if (tag == -1)
            {
                dicSort = (from objDic in dic orderby objDic.Key descending select objDic).ToList();
            }
            else
            {
                dicSort = (from objDic in dic orderby objDic.Key select objDic).ToList();
            }

            foreach (KeyValuePair<string, string> kvp in dicSort)
            {
                dic_result.Add(kvp.Key, kvp.Value);
            }

            return dic_result;
        }
        /// <summary>
        /// 获得MD5代码
        /// </summary>
        /// <param name="StrValue">要校验的字符串</param>
        /// <returns>36位的md5代码</returns>
        /// <remarks></remarks>
        public static string GetMD5(string StrValue)
        {
            return System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(StrValue, "md5");
        }





        #region 密码验证
        /// <summary>
        /// 强密码(必须包含大小写字母和数字的组合，不能使用特殊字符，长度在6-15之间)
        /// </summary>
        /// <param name="account"></param>
        /// <returns></returns>
        public static bool CheckPwd(string password)
        {
            Regex reg = new Regex(@"^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,20}$");
            bool status = false;
            if (reg.IsMatch(password))
            {
                status = true;
            }
            return status;
        }

        private static char[] constantNumber = { '0', '1', '2', '3', '5', '6', '7', '8', '9' };

        public static string GenerateRandomNumber(int Length)
        {
            string newRandom = "";
            Random rd = new Random();
            byte[] buffer = Guid.NewGuid().ToByteArray();
            int iSeed = BitConverter.ToInt32(buffer, 0);
            rd = new Random(iSeed); //随机数
            for (int i = 0; i < Length; i++)
            {
                // newRandom.Append(constant[rd.Next(62)]);
                newRandom += constantNumber[rd.Next(9)];
            }
            return newRandom;
        }

        #endregion

        /// <summary>
        /// 检查是否包含特殊字符
        /// </summary>
        /// <param name="str"></param>
        /// <returns>包含返回true</returns>
        public static bool CheckSpecialChar(string str)
        {
            bool status = false;
            bool bl_exist = false;
            foreach (char c in str)
            {
                if ((!char.IsLetter(c)) && (!char.IsNumber(c)))
                {//既不是字母又不是数字的就认为是特殊字符
                    bl_exist = true;
                }
            }
            if (bl_exist)
            {
                status = true;
            }
            return status;
        }

        /// <summary>
        /// 检查字符的长度
        /// </summary>
        /// <param name="str">检查字符</param>
        /// <param name="len">最大长度</param>
        /// <returns>超过len返回true</returns>
        public static bool CheckStrLength(string str, int len)
        {
            bool status = false;
            int v_length = System.Text.Encoding.Default.GetBytes(str).Length;
            if (v_length > len)
            {
                return true;
            }
            return status;
        }

        /// <summary>
        /// 检查是否包含数字
        /// </summary>
        /// <param name="str"></param>
        /// <returns>包含返回true</returns>
        public static bool CheckHaveNumber(string str)
        {
            bool status = false;
            bool bl_exist = false;
            foreach (char c in str)
            {
                if (char.IsNumber(c))
                {//包含数字
                    bl_exist = true;
                    break;
                }
            }
            if (bl_exist)
            {
                status = true;
            }
            return status;
        }


        #region 文件处理Tools
        public static string UploadImgs(byte[] bytes, string pImgName, string pImgPath, out bool uploadStatus, out string saveFileName)
        {
            uploadStatus = false;
            saveFileName = string.Empty;
            return pUploadImgs(bytes, pImgName, pImgPath, out uploadStatus, out saveFileName);
        }

        private static string pUploadImgs(byte[] bytes, string pImgName, string pImgPath, out bool uploadStatus, out string saveFileName)
        {
            saveFileName = string.Empty;
            try
            {
                //限制图片格式
                bool Isimage = false;
                uploadStatus = false;
                string suff = pImgName.Substring(pImgName.LastIndexOf('.'), pImgName.Length - pImgName.LastIndexOf('.'));  //获取文件后缀
                string[] allowExtension = { ".jpg", ".jpeg", ".gif", ".bmp", ".png", ".JPG", ".JPEG", ".GIF", ".BMP", ".PNG" };
                for (int i = 0; i < allowExtension.Length; i++)
                {
                    if (suff == allowExtension[i])
                    {
                        Isimage = true;
                        break;
                    }
                    else
                    { Isimage = false; }
                }
                if (!Isimage)
                {
                    uploadStatus = false;
                    return "图片格式不正确，上传失败";
                }
                // 图片数据
                Stream stream = new MemoryStream(bytes);//数据转换
                if (!string.IsNullOrEmpty(ConfigHelper.GetAppSettings("FileSize")))
                {
                    if (stream.Length > int.Parse(ConfigHelper.GetAppSettings("FileSize")))
                    {
                        uploadStatus = false;
                        return "图片大小超过1M，上传失败";
                    }
                    else
                    {
                        MemoryStream ms = new MemoryStream();
                        System.Drawing.Image img = System.Drawing.Image.FromStream(stream);
                        string imgName = DateTime.Now.ToString("yyyyMMddHHmmssffff") + suff;  //图片名称
                        string filedir = Path.Combine(pImgPath, imgName);
                        img.Save(filedir);//保存
                        ms.Close();
                        uploadStatus = true;
                        saveFileName = imgName;
                        return filedir;
                    }
                }
                else
                {
                    uploadStatus = false;
                    return "图片大小最大值限制 未配置";
                }
            }
            catch (Exception ex)
            {
                uploadStatus = false;
                return ex.Message;
            }
        }
        #endregion
    }

    public static class DataTableExtension
    {
        /// <summary>
        /// DataTable 转换为List 集合
        /// </summary>
        /// <typeparam name="TResult">类型</typeparam>
        /// <param name="dt">DataTable</param>
        /// <returns></returns>
        public static List<T> ToList<T>(this DataTable dt) where T : class, new()
        {
            //创建一个属性的列表
            List<PropertyInfo> prlist = new List<PropertyInfo>();
            //获取TResult的类型实例  反射的入口
            Type t = typeof(T);
            //获得TResult 的所有的Public 属性 并找出TResult属性和DataTable的列名称相同的属性(PropertyInfo) 并加入到属性列表 
            Array.ForEach<PropertyInfo>(t.GetProperties(), p => { if (dt.Columns.IndexOf(p.Name) != -1) prlist.Add(p); });
            //创建返回的集合
            List<T> oblist = new List<T>();

            foreach (DataRow row in dt.Rows)
            {
                //创建TResult的实例
                T ob = new T();
                //找到对应的数据  并赋值
                prlist.ForEach(p => { if (row[p.Name] != DBNull.Value) p.SetValue(ob, row[p.Name], null); });
                //放入到返回的集合中.
                oblist.Add(ob);
            }
            return oblist;
        }
    }

    public class EcanRMB
    {
        /// <summary>
        /// 转换人民币大小金额
        /// </summary>
        /// <param name="num">金额</param>
        /// <returns>返回大写形式</returns>
        public string CmycurD(decimal num)
        {
            string str1 = "零壹贰叁肆伍陆柒捌玖";            //0-9所对应的汉字
            string str2 = "万仟佰拾亿仟佰拾万仟佰拾元角分"; //数字位所对应的汉字
            string str3 = "";    //从原num值中取出的值
            string str4 = "";    //数字的字符串形式
            string str5 = "";  //人民币大写金额形式
            int i;    //循环变量
            int j;    //num的值乘以100的字符串长度
            string ch1 = "";    //数字的汉语读法
            string ch2 = "";    //数字位的汉字读法
            int nzero = 0;  //用来计算连续的零值是几个
            int temp;            //从原num值中取出的值

            num = Math.Round(Math.Abs(num), 2);    //将num取绝对值并四舍五入取2位小数
            str4 = ((long)(num * 100)).ToString();        //将num乘100并转换成字符串形式
            j = str4.Length;      //找出最高位
            if (j > 15) { return "溢出"; }
            str2 = str2.Substring(15 - j);   //取出对应位数的str2的值。如：200.55,j为5所以str2=佰拾元角分

            //循环取出每一位需要转换的值
            for (i = 0; i < j; i++)
            {
                str3 = str4.Substring(i, 1);          //取出需转换的某一位的值
                temp = Convert.ToInt32(str3);      //转换为数字
                if (i != (j - 3) && i != (j - 7) && i != (j - 11) && i != (j - 15))
                {
                    //当所取位数不为元、万、亿、万亿上的数字时
                    if (str3 == "0")
                    {
                        ch1 = "";
                        ch2 = "";
                        nzero = nzero + 1;
                    }
                    else
                    {
                        if (str3 != "0" && nzero != 0)
                        {
                            ch1 = "零" + str1.Substring(temp * 1, 1);
                            ch2 = str2.Substring(i, 1);
                            nzero = 0;
                        }
                        else
                        {
                            ch1 = str1.Substring(temp * 1, 1);
                            ch2 = str2.Substring(i, 1);
                            nzero = 0;
                        }
                    }
                }
                else
                {
                    //该位是万亿，亿，万，元位等关键位
                    if (str3 != "0" && nzero != 0)
                    {
                        ch1 = "零" + str1.Substring(temp * 1, 1);
                        ch2 = str2.Substring(i, 1);
                        nzero = 0;
                    }
                    else
                    {
                        if (str3 != "0" && nzero == 0)
                        {
                            ch1 = str1.Substring(temp * 1, 1);
                            ch2 = str2.Substring(i, 1);
                            nzero = 0;
                        }
                        else
                        {
                            if (str3 == "0" && nzero >= 3)
                            {
                                ch1 = "";
                                ch2 = "";
                                nzero = nzero + 1;
                            }
                            else
                            {
                                if (j >= 11)
                                {
                                    ch1 = "";
                                    nzero = nzero + 1;
                                }
                                else
                                {
                                    ch1 = "";
                                    ch2 = str2.Substring(i, 1);
                                    nzero = nzero + 1;
                                }
                            }
                        }
                    }
                }
                if (i == (j - 11) || i == (j - 3))
                {
                    //如果该位是亿位或元位，则必须写上
                    ch2 = str2.Substring(i, 1);
                }
                str5 = str5 + ch1 + ch2;

                if (i == j - 1 && str3 == "0")
                {
                    //最后一位（分）为0时，加上“整”
                    str5 = str5 + '整';
                }
            }
            if (num == 0)
            {
                str5 = "零元整";
            }
            return str5;
        }

        /**/
        /// <summary>
        /// 一个重载，将字符串先转换成数字在调用CmycurD(decimal num)
        /// </summary>
        /// <param name="num">用户输入的金额，字符串形式未转成decimal</param>
        /// <returns></returns>
        public string CmycurD(string numstr)
        {
            try
            {
                decimal num = Convert.ToDecimal(numstr);
                return CmycurD(num);
            }
            catch
            {
                return "非数字形式！";
            }
        }
    }


}

