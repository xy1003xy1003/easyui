﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;

namespace EasyUIDemo.DBUtility
{
    public class Excel
    {
        /// <summary>
        /// 导出Excel
        /// </summary>
        /// <param name="name">文件地址</param>
        /// <param name="dt">数据源</param>
        /// <param name="colsHt">自定义列hash</param>
        /// <param name="CustomColumn">是否自定义列</param>
        /// <param name="sheetName">sheet名称</param>
        public static void ExportExcel(string name,DataTable dt,string[] colsHt,bool CustomColumn,string sheetName)
        {            
            NPOI.SS.UserModel.IWorkbook book = null;
            //book = new NPOI.HSSF.UserModel.HSSFWorkbook();
            book = new NPOI.XSSF.UserModel.XSSFWorkbook();

            NPOI.SS.UserModel.ISheet sheet = book.CreateSheet(sheetName);

            // 添加表头
            NPOI.SS.UserModel.IRow row = sheet.CreateRow(0);
            int index = 0;
            if (CustomColumn && colsHt!=null)
            {
                foreach (string item in colsHt)
                {
                    NPOI.SS.UserModel.ICell cell = row.CreateCell(index);
                    cell.SetCellType(NPOI.SS.UserModel.CellType.STRING);
                    cell.SetCellValue(item.Split(',')[0]);
                    //当前列值的长度
                    int v_length = System.Text.Encoding.Default.GetBytes(item.Split(',')[0].ToString()).Length;
                    sheet.SetColumnWidth(index, 256 * v_length);
                    index++;
                }
                // 添加数据
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    index = 0;
                    row = sheet.CreateRow(i + 1);
                    foreach (string item in colsHt)
                    {
                        NPOI.SS.UserModel.ICell cell = row.CreateCell(index);
                        string val = dt.Rows[i][item.Split(',')[1]].ToString();                        
                        cell.SetCellType(NPOI.SS.UserModel.CellType.STRING);
                        cell.SetCellValue(val);
                        //当前列值的长度
                        int v_length = System.Text.Encoding.Default.GetBytes(val).Length;
                        //当前列的宽度
                        int currColumn_width = sheet.GetColumnWidth(index);
                        if (v_length == 0)
                        {
                            string colName = sheet.GetRow(0).GetCell(index).StringCellValue;
                            int colName_length = System.Text.Encoding.Default.GetBytes(colName).Length;
                            sheet.SetColumnWidth(index, 256 * colName_length);
                        }
                        if (currColumn_width <= (256 * v_length))
                        {
                            sheet.SetColumnWidth(index, 256 * v_length + 256);
                        }
                        index++;
                    }
                }
            }
            else
            {
                foreach (DataColumn item in dt.Columns)
                {
                    NPOI.SS.UserModel.ICell cell = row.CreateCell(index);
                    cell.SetCellType(NPOI.SS.UserModel.CellType.STRING);
                    cell.SetCellValue(item.Caption);
                    //当前列值的长度
                    int v_length = System.Text.Encoding.Default.GetBytes(item.Caption).Length;
                    sheet.SetColumnWidth(index, 256 * v_length);
                    index++;
                }
                // 添加数据
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    index = 0;
                    row = sheet.CreateRow(i + 1);
                    foreach (DataColumn item in dt.Columns)
                    {
                        NPOI.SS.UserModel.ICell cell = row.CreateCell(index);
                        string val = dt.Rows[i][item].ToString();
                        cell.SetCellType(NPOI.SS.UserModel.CellType.STRING);
                        cell.SetCellValue(val);
                        //当前列值的长度
                        int v_length = System.Text.Encoding.Default.GetBytes(val).Length;
                        //当前列的宽度
                        int currColumn_width = sheet.GetColumnWidth(index);
                        if (v_length == 0)
                        {
                            string colName = sheet.GetRow(0).GetCell(index).StringCellValue;
                            int colName_length = System.Text.Encoding.Default.GetBytes(colName).Length;
                            sheet.SetColumnWidth(index, 256 * colName_length);
                        }
                        if (currColumn_width <= (256 * v_length))
                        {
                            sheet.SetColumnWidth(index, 256 * v_length + 256);
                        }
                        index++;
                    }
                }
            }
            // 写入 
            System.IO.MemoryStream ms = new System.IO.MemoryStream();
            book.Write(ms);
            book = null;
            using (FileStream fs = new FileStream(name, FileMode.Create, FileAccess.Write))
            {
                byte[] data = ms.ToArray();
                fs.Write(data, 0, data.Length);
                fs.Flush();
            }            
            ms.Close();
            ms.Dispose();
        }
    }
}
