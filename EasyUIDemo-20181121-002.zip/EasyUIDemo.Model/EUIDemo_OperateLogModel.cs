﻿using System;
namespace EasyUIDemo.Model
{
    /// <summary>
    /// EUIDemo_OperateLog:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class EUIDemo_OperateLogModel
    {
        public EUIDemo_OperateLogModel()
        { }
        #region Model
        private int _id;
        private DateTime _operatedate = DateTime.Now;
        private string _operatetype = "";
        private string _operatename = "";
        private string _operatecontent = "";
        private string _operateip = "";
        private int _operateid = 0;
        private string _operateaccount = "";
        private decimal _operateamount = 0.0000M;
        private string _operateremark = "";
        private DateTime _updatetime = DateTime.Now;
        /// <summary>
        /// 
        /// </summary>
        public int ID
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime OperateDate
        {
            set { _operatedate = value; }
            get { return _operatedate; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string OperateType
        {
            set { _operatetype = value; }
            get { return _operatetype; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string OperateName
        {
            set { _operatename = value; }
            get { return _operatename; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string OperateContent
        {
            set { _operatecontent = value; }
            get { return _operatecontent; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string OperateIP
        {
            set { _operateip = value; }
            get { return _operateip; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int OperateID
        {
            set { _operateid = value; }
            get { return _operateid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string OperateAccount
        {
            set { _operateaccount = value; }
            get { return _operateaccount; }
        }
        /// <summary>
        /// 
        /// </summary>
        public decimal OperateAmount
        {
            set { _operateamount = value; }
            get { return _operateamount; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string OperateRemark
        {
            set { _operateremark = value; }
            get { return _operateremark; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime UpdateTime
        {
            set { _updatetime = value; }
            get { return _updatetime; }
        }
        #endregion Model

    }
}

