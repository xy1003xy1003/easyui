﻿using System;
namespace EasyUIDemo.Model
{
	/// <summary>
	/// EUIDemo_AdminLogin:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class EUIDemo_AdminLoginModel
	{
		public EUIDemo_AdminLoginModel()
		{}
		#region Model
		private int _id;
		private string _loginname;
		private string _password;
		private string _managmentdepartment;
		private string _managmentrole;
		private string _operationdepartment;
		private string _operationrole;
		private string _realname;
		private string _mobile;
		private int _status;
		private string _remark;
		private DateTime _createdate;
		private string _auditor;
		private DateTime _audittime;
		private DateTime _updatetime;
		/// <summary>
		/// 
		/// </summary>
		public int ID
		{
			set{ _id=value;}
			get{return _id;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string LoginName
		{
			set{ _loginname=value;}
			get{return _loginname;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string Password
		{
			set{ _password=value;}
			get{return _password;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string ManagmentDepartment
		{
			set{ _managmentdepartment=value;}
			get{return _managmentdepartment;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string ManagmentRole
		{
			set{ _managmentrole=value;}
			get{return _managmentrole;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string OperationDepartment
		{
			set{ _operationdepartment=value;}
			get{return _operationdepartment;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string OperationRole
		{
			set{ _operationrole=value;}
			get{return _operationrole;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string RealName
		{
			set{ _realname=value;}
			get{return _realname;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string Mobile
		{
			set{ _mobile=value;}
			get{return _mobile;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int Status
		{
			set{ _status=value;}
			get{return _status;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string Remark
		{
			set{ _remark=value;}
			get{return _remark;}
		}
		/// <summary>
		/// 
		/// </summary>
		public DateTime CreateDate
		{
			set{ _createdate=value;}
			get{return _createdate;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string Auditor
		{
			set{ _auditor=value;}
			get{return _auditor;}
		}
		/// <summary>
		/// 
		/// </summary>
		public DateTime AuditTime
		{
			set{ _audittime=value;}
			get{return _audittime;}
		}
		/// <summary>
		/// 
		/// </summary>
		public DateTime UpdateTime
		{
			set{ _updatetime=value;}
			get{return _updatetime;}
		}
		#endregion Model

	}
}

