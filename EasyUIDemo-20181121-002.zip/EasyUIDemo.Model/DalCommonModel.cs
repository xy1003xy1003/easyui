﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EasyUIDemo.Model
{
    class DalCommonModel
    {
    }

    /// <summary>
    /// 提现拒绝  或者提现失败退回
    /// </summary>
    public class proc_zka_withdrawals_failModel
    {

        /// <summary>
        /// 提现记录id
        /// </summary>
        public int WithdrawKID { get; set; }

        /// <summary>
        /// 提现金额
        /// </summary>
        public decimal WithdrawAmount { get; set; }

        /// <summary>
        /// 手续费
        /// </summary>
        public decimal DeductionFee { get; set; }

        /// <summary>
        /// 失败原因
        /// </summary>
        public string FailReason { get; set; }


        /// <summary>
        /// 操作员
        /// </summary>
        public int Operator { get; set; }
    }

    /// <summary>
    /// 上门自提
    /// </summary>
    public class proc_zx_ht_mall_product_self_pick_payModel
    {
        public proc_zx_ht_mall_product_self_pick_payModel()
        {
            UserSystem = "宗客网代理商系统";
            UserType = "代销会员";
        }

        public int LoginId { get; set; }

        public string LoginName { get; set; }

        /// <summary>
        /// 流水号
        /// </summary>
        public string SerialNum { get; set; }

        /// <summary>
        /// 产品编号
        /// </summary>
        public string ProductCode { get; set; }

        /// <summary>
        /// 产品名称
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// 重量
        /// </summary>
        public decimal ProductWeight { get; set; }

        /// <summary>
        /// 金额
        /// </summary>
        public decimal ProductAmount { get; set; }

        /// <summary>
        /// 收货人
        /// </summary>
        public string Consignee { get; set; }

        /// <summary>
        /// 自提时间
        /// </summary>
        public DateTime SelfPickDate { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }

        /// <summary>
        /// 付款用户类别: ( '代销会员' )
        /// </summary>
        public string UserType { get; set; }

        /// <summary>
        /// 用户所属系统: ( '宗客网代理商系统' )
        /// </summary>
        public string UserSystem { get; set; }

        /// <summary>
        /// 扣款账号ID
        /// </summary>
        public int MemberID { get; set; }

        /// <summary>
        /// 扣款账号
        /// </summary>
        public string MemberAccount { get; set; }

        /// <summary>
        /// 扣款账号类别: ('CurrencyFund','SubsidyFund','SelfCoupon')
        /// </summary>
        public string AccountType { get; set; }

        /// <summary>
        /// 扣款账号类别描述: ('通用账户','可用金额','自销产品券')
        /// </summary>
        public string AccountTypeDesc { get; set; }

        /// <summary>
        /// 操作人
        /// </summary>
        public int OperateID { get; set; }

        /// <summary>
        /// 操作人姓名
        /// </summary>
        public string OperateName { get; set; }
    }
}
