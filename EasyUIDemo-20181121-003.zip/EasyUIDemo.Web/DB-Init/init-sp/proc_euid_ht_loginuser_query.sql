-- �ж�Ҫ�����Ĵ洢�������Ƿ����
IF EXISTS (SELECT * FROM DBO.SYSOBJECTS WHERE ID =OBJECT_ID(N'[dbo].[proc_euid_ht_loginuser_query]') AND OBJECTPROPERTY(ID, N'ISPROCEDURE')= 1)
-- ɾ���洢����
DROP PROCEDURE [dbo].[proc_euid_ht_loginuser_query]
GO

CREATE PROCEDURE [dbo].[proc_euid_ht_loginuser_query](
	@Operator		    NVARCHAR(20),				--������
	@UserAccount		NVARCHAR(20),				--��¼�û���
	@PageSize			INT,						--ÿҳ��ʾ������
	@PageIndex			INT,						--��ʾ�ڼ�ҳ
	@TotalRecord		INT		OUTPUT				--�ܼ�¼��
)
AS
BEGIN

	BEGIN TRY 

		DECLARE @TranFlag INT
		SELECT  @TranFlag = @@TRANCOUNT
		IF @TranFlag = 0
		BEGIN TRAN tran_euid_ht_loginuser_query
		ELSE
		SAVE TRAN tran_euid_ht_loginuser_query

		DECLARE @SqlStr			NVARCHAR(MAX)
		DECLARE @WhereStr		NVARCHAR(MAX)
		DECLARE @BeginIndex		INT
		DECLARE @EndIndex		INT
		SET @BeginIndex = (@PageIndex - 1) * @PageSize + 1  --��ʼ
		SET @EndIndex = (@PageIndex) * @PageSize			--����
		SET @TotalRecord = 0

		--�жϲ���Ա�˺��Ƿ���Ч
		IF EXISTS(SELECT 1 FROM dbo.EUIDemo_tbUser WHERE AccountName = @Operator AND IsAble <> 1)
		BEGIN
			ROLLBACK TRAN tran_euid_ht_loginuser_query
			RETURN -1061	--����Ա�˺���ʧЧ
		END 
		
		----��ȡ����������Role
		--DECLARE @OperationRole		NVARCHAR(20)
		--SELECT @OperationRole = OperationRole FROM dbo.EUIDemo_AdminLogin WHERE LoginName = @Operator

		--IF @OperationRole NOT IN  (1,55,63) --SELECT * FROM EUIDemo_tbRole
		--BEGIN 
		--	ROLLBACK TRAN tran_euid_ht_loginuser_query
		--	RETURN -1062   --����Ա�˺Ų���Ȩ�޲���
		--END 


		--SELECT * FROM EUIDemo_AdminLogin
		--SELECT LoginName, B.RoleName, RealName, Mobile, CreateDate, Auditor, AuditTime, A.UpdateTime FROM EUIDemo_AdminLogin A
		--INNER JOIN EUIDemo_tbRole B
		--ON A.OperationRole = B.Id
		
		--��������
		SELECT @WhereStr =	' WHERE A.IsAble = 1 '
		IF @UserAccount != ''
		BEGIN
			SELECT @WhereStr = @WhereStr +  ' AND A.LoginName = ''' + @UserAccount + ''' '
		END

		SELECT @SqlStr =			' SELECT * FROM (SELECT ROW_NUMBER() OVER(ORDER BY A.CreateTime DESC) as Rownum, '
		SELECT @SqlStr = @SqlStr +  '	A.ID, A.AccountName AS LoginName, C.RoleName, A.RealName, A.MobilePhone AS Mobile, A.CreateBy AS Auditor, '
		SELECT @SqlStr = @SqlStr +  '	CONVERT(VARCHAR,A.CreateTime,111) AS CreateDate, '
		SELECT @SqlStr = @SqlStr +  '	CONVERT(VARCHAR,A.UpdateTime,111) AS UpdateTime, '
		SELECT @SqlStr = @SqlStr +  '	CONVERT(VARCHAR,A.CreateTime,111) AS AuditTime '
		SELECT @SqlStr = @SqlStr +  ' FROM '
		SELECT @SqlStr = @SqlStr +  '	EUIDemo_tbUser A '
		SELECT @SqlStr = @SqlStr +  ' INNER JOIN '
		SELECT @SqlStr = @SqlStr +  '	EUIDemo_tbUserRole B '
		SELECT @SqlStr = @SqlStr +  ' ON A.ID = B.UserId '
		SELECT @SqlStr = @SqlStr +  ' INNER JOIN '
		SELECT @SqlStr = @SqlStr +  '	EUIDemo_tbRole C '
		SELECT @SqlStr = @SqlStr +  ' ON B.RoleId = C.Id '
		SELECT @SqlStr = @SqlStr +  @WhereStr + ' ) AS T '
		SELECT @SqlStr = @SqlStr +  ' WHERE T.ROWNUM BETWEEN ' + cast(@BeginIndex as nvarchar) + ' AND ' + cast(@EndIndex as nvarchar)
		--��ѯTotalRecordֵ
		SELECT @SqlStr = @SqlStr +  ' SELECT COUNT(*) FROM EUIDemo_tbUser A '
		SELECT @SqlStr = @SqlStr +  ' INNER JOIN '
		SELECT @SqlStr = @SqlStr +  '	EUIDemo_tbUserRole B '
		SELECT @SqlStr = @SqlStr +  ' ON A.ID = B.UserId '
		SELECT @SqlStr = @SqlStr +  ' INNER JOIN '
		SELECT @SqlStr = @SqlStr +  '	EUIDemo_tbRole C '
		SELECT @SqlStr = @SqlStr +  ' ON B.RoleId = C.Id '
		SELECT @SqlStr = @SqlStr +  @WhereStr
		--PRINT @SqlStr
		EXEC  (@SqlStr)



		--�ύ����
		COMMIT TRAN tran_euid_ht_loginuser_query
		RETURN 0
	END TRY  

	BEGIN CATCH  
		IF @@TRANCOUNT > 0  
			BEGIN
				ROLLBACK TRAN tran_euid_ht_loginuser_query
				INSERT INTO ERROR_MSG_LOG(ERROR_NUMBER,ERROR_SEVERITY,ERROR_STATE,ERROR_PROCEDURE,ERROR_LINE,ERROR_MESSAGE,OPERATOR,INSERT_TIME)    -- VALUES(1,2,3,'',5,'',GETDATE())
				SELECT ERROR_NUMBER() AS �����,ERROR_SEVERITY() AS ���ؼ���,ERROR_STATE() AS ����״̬��,ERROR_PROCEDURE() AS �洢���̻򴥷���������,ERROR_LINE() AS ���´�����к�,ERROR_MESSAGE() AS ������Ϣ,'',GETDATE()
				RETURN -1000 
			END 
	END CATCH  
END
