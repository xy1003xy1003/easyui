-- �ж�Ҫ�����Ĵ洢�������Ƿ����
IF EXISTS (SELECT * FROM DBO.SYSOBJECTS WHERE ID =OBJECT_ID(N'[dbo].[proc_euid_ht_loginuser_add]') AND OBJECTPROPERTY(ID, N'ISPROCEDURE')= 1)
-- ɾ���洢����
DROP PROCEDURE [dbo].[proc_euid_ht_loginuser_add]
GO

CREATE PROCEDURE [dbo].[proc_euid_ht_loginuser_add](
	@LoginAccount		NVARCHAR(20),			--��¼�˺�
	@UserPass			NVARCHAR(50),			--��¼����
	@UserRole			NVARCHAR(50),			--������ɫ
	@UserMoblie			NVARCHAR(20),			--�ֻ�����
	@RealName			NVARCHAR(20),			--��ʵ����
	@Remark				NVARCHAR(200),			--��ע
	@Operator			NVARCHAR(20)			--�����˺�
)
AS
BEGIN

	BEGIN TRY 
	
		DECLARE @TranFlag INT
		SELECT  @TranFlag = @@TRANCOUNT
		IF @TranFlag = 0
		BEGIN TRAN tran_euid_ht_loginuser_add
		ELSE
		SAVE TRAN tran_euid_ht_loginuser_add
		
		IF @LoginAccount IS NULL OR @LoginAccount = '' OR @UserPass = ''
		BEGIN
			ROLLBACK TRAN tran_euid_ht_loginuser_add		
			RETURN -3005   --�����쳣
		END

		
		IF EXISTS(SELECT 1 FROM EUIDemo_AdminLogin WHERE  Status >= 0 AND LoginName = @LoginAccount)
		BEGIN
			ROLLBACK TRAN tran_euid_ht_loginuser_add		
			RETURN -3005   --�����쳣
		END

		IF EXISTS(SELECT 1 FROM EUIDemo_AdminLogin WHERE  Status < 0 AND LoginName = @LoginAccount)
		BEGIN
			--��ӵ��,��Ҫ����
			UPDATE EUIDemo_AdminLogin
			SET    
				   Password = @UserPass,
				   OperationRole = @UserRole,
				   RealName = @RealName,
				   Mobile = @UserMoblie,
				   Remark = @Remark,
				   Auditor = @Operator,
				   AuditTime = GETDATE(),
				   Status = 1,
				   UpdateTime = GETDATE()
			WHERE  Status < 0
				   AND LoginName = @LoginAccount 
		END
		ELSE
		BEGIN
			--δӵ��,��Ҫ����
			INSERT INTO [dbo].[EUIDemo_AdminLogin]
				([LoginName]
				,[Password]
				,[ManagmentDepartment]
				,[ManagmentRole]
				,[OperationDepartment]
				,[OperationRole]
				,[RealName]
				,[Mobile]
				,[Status]
				,[Remark]
				,[CreateDate]
				,[Auditor]
				,[AuditTime]
				,[UpdateTime])
			VALUES
				(@LoginAccount
				,@UserPass
				,''
				,''
				,''
				,@UserRole
				,@RealName
				,@UserMoblie
				,1
				,@Remark
				,GETDATE()
				,@Operator
				,GETDATE()
				,GETDATE())
		END
		
		IF @@ROWCOUNT > 1 
		BEGIN 
			ROLLBACK TRAN tran_euid_ht_loginuser_add		
			RETURN -3005   --�����쳣
		END

		--�ύ����
		COMMIT TRAN tran_euid_ht_loginuser_add
		RETURN 0
	END TRY  

	BEGIN CATCH  
		IF @@TRANCOUNT > 0  
			BEGIN
				ROLLBACK TRAN tran_euid_ht_loginuser_add
				INSERT INTO ERROR_MSG_LOG(ERROR_NUMBER,ERROR_SEVERITY,ERROR_STATE,ERROR_PROCEDURE,ERROR_LINE,ERROR_MESSAGE,OPERATOR,INSERT_TIME)    -- VALUES(1,2,3,'',5,'',GETDATE())
				SELECT ERROR_NUMBER() AS �����,ERROR_SEVERITY() AS ���ؼ���,ERROR_STATE() AS ����״̬��,ERROR_PROCEDURE() AS �洢���̻򴥷���������,ERROR_LINE() AS ���´�����к�,ERROR_MESSAGE() AS ������Ϣ,'',GETDATE()
				RETURN -1000 
			END 
	END CATCH 
END

