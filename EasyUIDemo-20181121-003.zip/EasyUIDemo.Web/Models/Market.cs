﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EasyUIDemo.Web.Models
{
    public class Market
    {
        public int id { get; set; }
        public string code { get; set; }
        public string name { get; set; }
        public string type { get; set; }
        public int userid { get; set; }
        public string useraccount { get; set; }
        public string dutyperson { get; set; }
        public string mobile { get; set; }
        public string theoptdepartment { get; set; }
        public DateTime createdate { get; set; }
        public string Operator { get; set; }
        public int status { get; set; }
        public DateTime updatetime { get; set; }
        public string remark { get; set; }
    }



    public class ReturnViewModel
    {
        public ReturnViewModel()
        {
            success = false;
            msg = "失败";
            content = "";
        }

        public bool success { get; set; }

        public string msg { get; set; }

        public string content { get; set; }
    }
}