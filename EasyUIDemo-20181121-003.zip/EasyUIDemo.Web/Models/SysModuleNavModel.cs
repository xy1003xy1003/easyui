﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EasyUIDemo.Web.Models
{
    public class SysModuleNavModel
    {
        public string id { get; set; }
        public string text { get; set; }
        public string iconCls { get; set; }
        public string attributes { get; set; }
        public string state { get; set; }
        public List<SysModuleNavModel> children { get; set; }
    }
    
    /// <summary>
    /// 账户中心
    /// </summary>
    public class AccountMoney
    {
        public AccountMoney()
        {
            TotalMoney = 0.00M;
            StoreMoney = 0.00M;
            Coupon = 0.00M;
            SalesCoupon = 0.00M;
            CurrencyCoupon = 0.00M;
            logintype = 0;
            LockSelfCoupon = 0.00M;
            LockCurrencyCoupon = 0.00M;
            LockTotalMoney = 0.00M;

        }

        /// <summary>
        /// 锁定账户可用金额
        /// </summary>
        public decimal LockTotalMoney { get; set; }


        /// <summary>
        /// 账户通用用金额
        /// </summary>
        public decimal TotalMoney { get; set; }

        /// <summary>
        /// 店补金额
        /// </summary>
        public decimal StoreMoney { get; set; }

        /// <summary>
        /// 购物券
        /// </summary>
        public decimal Coupon { get; set; }

        /// <summary>
        ///  自销产品券
        /// </summary>
        public decimal SalesCoupon { get; set; }

        /// <summary>
        ///  通用产品券
        /// </summary>
        public decimal CurrencyCoupon { get; set; }

        public int logintype { get; set; }

        public string logintypename { get; set; }

        /// <summary>
        /// 可用金额
        /// </summary>
        public decimal KYCurrencyCoupon { get; set; }

        /// <summary>
        /// 代理商自销券
        /// </summary>
        public decimal AgentSelfCoupon { get; set; }

        /// <summary>
        /// 代理商助销券
        /// </summary>
        public decimal AgentHelpCoupon { get; set; }

        /// <summary>
        /// 自销产品券
        /// </summary>
        public decimal LockSelfCoupon { get; set; }

        /// <summary>
        /// 通用产品券
        /// </summary>
        public decimal LockCurrencyCoupon { get; set; }

        public string MemberPhone { get; set; }

        /// <summary>
        /// 是否代理商
        /// </summary>
        public int IsAgent { get; set; }
    }
}