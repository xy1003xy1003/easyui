﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EasyUIDemo.Web.Models
{
    public class VIPManageViewModel
    {
    }

    /// <summary>
    /// 退款申请视图实体
    /// </summary>
    public class OrderBackApplyViewModel
    {
        /// <summary>
        /// 手机号
        /// </summary>
        public string Phone { get; set; }

        /// <summary>
        /// 姓名
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 退款金额
        /// </summary>
        public decimal BackMoney { get; set; }

        /// <summary>
        /// 退款比例
        /// </summary>
        public decimal BackFee { get; set; }

        /// <summary>
        /// 推荐人
        /// </summary>
        public string Recommender { get; set; }

        /// <summary>
        /// 所属部门
        /// </summary>
        public string dept { get; set; }

        /// <summary>
        /// 退款原因
        /// </summary>
        public string BackReason { get; set; }

        /// <summary>
        /// 审核状态
        /// </summary>
        public string CheckStatus { get; set; }

        public DateTime ApplyTime { get; set; }

        public int ID { get; set; }
    }
}