﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EasyUIDemo.Web.Models
{
    public class ContractPrintModel
    {
    }

   
    public  class CustContractPrintModel
    {
        
        #region Model
       
        
        
        /// <summary>
        /// 合同编号
        /// </summary>
        public string ContractCode
        {
            get;set;
        }
        /// <summary>
        /// 大客户编号
        /// </summary>
        public int CustID
        {
            get;set;
        }
        /// <summary>
        /// 大客户账号
        /// </summary>
        public string CustAccount
        {
            get; set;
        }
        /// <summary>
        /// 大客户姓名
        /// </summary>
        public string CustName
        {
            get; set;
        }
        /// <summary>
        /// 大客户手机号
        /// </summary>
        public string CustMobile
        {
            get; set;
        }
        /// <summary>
        /// 大客户身份证
        /// </summary>
        public string CustIDCard
        {
            get; set;
        }
        /// <summary>
        /// 大客户订单号
        /// </summary>
        public int OrderID
        {
            get; set;
        }
        /// <summary>
        /// 订单类型
        /// </summary>
        public int OrderType
        {
            get; set;
        }
        /// <summary>
        /// 订单日期
        /// </summary>
        public DateTime OrderDate
        {
            get; set;
        }
        /// <summary>
        /// 订单数量
        /// </summary>
        public int OrderNum
        {
            get; set;
        }
        /// <summary>
        /// 订单单价
        /// </summary>
        public decimal UnitPrice
        {
            get; set;
        }
        /// <summary>
        /// 订单总价
        /// </summary>
        public decimal TotalPrice
        {
            get; set;
        }
        /// <summary>
        /// 订单激活日期
        /// </summary>
        public DateTime ActivationDate
        {
            get; set;
        }
        /// <summary>
        /// 过冷静期日期
        /// </summary>
        public DateTime CalmDate
        {
            get; set;
        }
        /// <summary>
        /// 过冷静期天数
        /// </summary>
        public int CalmDays
        {
            get; set;
        }
        /// <summary>
        /// 解锁日期
        /// </summary>
        public DateTime UnlockDate
        {
            get; set;
        }
        /// <summary>
        /// 自销券金额
        /// </summary>
        public decimal SelfCoupon
        {
            get; set;
        }
        /// <summary>
        /// 通用券金额
        /// </summary>
        public decimal CurrencyCoupon
        {
            get; set;
        }
        /// <summary>
        /// 首次打印日期
        /// </summary>
        public DateTime FirstPrintDate
        {
            get; set;
        }
        /// <summary>
        /// 打印次数
        /// </summary>
        public int PrintNum
        {
            get; set;
        }
        /// <summary>
        /// 合同KEY
        /// </summary>
        public string ContractKey
        {
            get; set;
        }
        /// <summary>
        /// 合同状态
        /// </summary>
        public int DealStatus
        {
            get; set;
        }
        /// <summary>
        /// 合同备注
        /// </summary>
        public string DealRemark
        {
            get; set;
        }

        /// <summary>
        /// 签订日期年
        /// </summary>
        public string YY
        { get; set; }

        /// <summary>
        /// 签订日期月
        /// </summary>
        public string MM
        { get; set; }

        /// <summary>
        /// 签订日期日
        /// </summary>
        public string DD
        { get; set; }

        #endregion Model

    }
}