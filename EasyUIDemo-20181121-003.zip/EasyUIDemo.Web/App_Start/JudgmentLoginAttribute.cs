﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EasyUIDemo.BLL;
using EasyUIDemo.DBUtility;
using EasyUIDemo.Model;

namespace EasyUIDemo.Web.App_Start
{
    /// <summary>
    /// 判断是否登录的过滤器
    /// </summary>
    public class JudgmentLoginAttribute : ActionFilterAttribute
    {
        public EUIDemo_AdminLoginModel accountmodelJudgment;

        //执行Action之前操作
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {

            //判断是否登录或是否用权限，如果有那么就进行相应的操作，否则跳转到登录页或者授权页面
            //string s_accountId = AES.DecryptStr(CookiesHelper.GetCookieValue("UserID"));
            string s_accountId = HttpContext.Current.Session["UserID"] == null ? null : HttpContext.Current.Session["UserID"].ToString();

            int i_accountId = 0;
            //判断是否有cookie
            if (int.TryParse(s_accountId, out i_accountId))
            {
                //EasyUIDemo.Model.UserEntity m_account = new EasyUIDemo.BLL.UserBLL().GetUserById(i_accountId.ToString());
                //if (m_account != null)
                //{
                //    accountmodelJudgment = m_account;
                //    filterContext.Controller.ViewData["Account"] = m_account;
                //    filterContext.Controller.ViewData["AccountName"] = m_account.AccountName;
                //    filterContext.Controller.ViewData["RealName"] = m_account.RealName;

                //    //处理Action之前操作内容根据我们提供的规则来定义这部分内容
                //    base.OnActionExecuting(filterContext);
                //}
                List<EUIDemo_AdminLoginModel> currentUsers = new EUIDemo_AdminLoginBLL().GetModelList("id=" + i_accountId);
                EUIDemo_AdminLoginModel currentUser = currentUsers.Count > 0 ? currentUsers[0] : null;

                string controllerName = (filterContext.RouteData.Values["controller"]).ToString().ToLower();

                if (HttpContext.Current.Request.UrlReferrer == null && (controllerName != "print" && controllerName != "contractprint"))
                {
                    HttpContext.Current.Session["UserID"] = null;
                    filterContext.Result = new RedirectResult("/Login/Index", false);
                    return;
                }

                if (currentUser != null)
                {
                    UserBLL userbll = new UserBLL();
                    //if (!userbll.sysmaintenanceCheck())
                    //{
                    //    if (currentUser.LoginName == "admin" || currentUser.LoginName == "系统管理员" || currentUser.LoginName == "10000" || currentUser.LoginName == "运营中心客服")
                    //    {

                    //    }
                    //    else
                    //    {
                    //        HttpContext.Current.Session["UserID"] = null;
                    //        filterContext.Result = new RedirectResult("/Login/Index", false);
                    //        return;
                    //    }
                    //}

                    accountmodelJudgment = currentUser;
                    filterContext.Controller.ViewData["Account"] = currentUser;
                    filterContext.Controller.ViewData["AccountName"] = currentUser.LoginName;
                    filterContext.Controller.ViewData["RealName"] = currentUser.LoginName;

                    //处理Action之前操作内容根据我们提供的规则来定义这部分内容
                    base.OnActionExecuting(filterContext);
                }
                else
                {
                    CookiesHelper.AddCookie("UserID", System.DateTime.Now.AddDays(-1));
                    //HttpContext.Current.Session["UserID"] = null;
                    //filterContext.Controller.ViewData["Account"] = null;
                    filterContext.Result = new RedirectResult("/Login/Index", false);
                }

            }
            else
            {
                //HttpContext.Current.Session["UserID"] = null;
                //filterContext.Controller.ViewData["Account"] = null;
                filterContext.Result = new RedirectResult("/Login/Index", false);
            }
        }
    }
}