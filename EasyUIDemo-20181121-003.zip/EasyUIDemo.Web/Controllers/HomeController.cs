﻿using EasyUIDemo.BLL;
using EasyUIDemo.Model;
using EasyUIDemo.Web.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;

namespace EasyUIDemo.Web.Controllers
{
    [EasyUIDemo.Web.App_Start.JudgmentLogin]
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            EUIDemo_AdminLoginModel uInfo = ViewData["Account"] as EUIDemo_AdminLoginModel;
            if (uInfo == null)
            {
                return RedirectToAction("Index", "Login");
            }
            ViewBag.RealName = uInfo.LoginName;
            ViewBag.TimeView = DateTime.Now.ToLongDateString();
            ViewBag.DayDate = System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.GetDayName(DateTime.Now.DayOfWeek);
            return View();
        }

        public ActionResult IndexNew()
        {
            UserEntity uInfo = ViewData["Account"] as UserEntity;
            if (uInfo == null)
            {
                return RedirectToAction("Index", "Login");
            }
            ViewBag.RealName = uInfo.RealName;
            ViewBag.TimeView = DateTime.Now.ToLongDateString();
            ViewBag.DayDate = System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.GetDayName(DateTime.Now.DayOfWeek);
            return View();
        }

        /// <summary>
        /// 查询出数据显示在菜单栏目中
        /// </summary>
        /// <returns></returns>
        public ActionResult LoadMenuData()
        {
            UserEntity uInfo = ViewData["Account"] as UserEntity;
            string menuJson = new MenuBLL().GetUserMenu(uInfo.ID);
            return Content(menuJson);
        }

        /// <summary>
        /// 判断是否修改密码
        /// </summary>
        /// <returns></returns>
        public ActionResult CheckIsChangePwd()
        {
            UserEntity uInfo = ViewData["Account"] as UserEntity;
            return Content("{\"msg\":" + new JavaScriptSerializer().Serialize(uInfo) + ",\"success\":true}");
        }

        /// <summary>
        /// 获取导航菜单
        /// </summary>
        /// <param name="id">所属</param>
        /// <returns>树</returns>
        public JsonResult GetTreeByEasyui(string id)
        {
            try
            {
                EUIDemo_AdminLoginModel uInfo = ViewData["Account"] as EUIDemo_AdminLoginModel;
                if (uInfo != null)
                {
                    DataTable dt = new MenuBLL().GetUserMenuData(uInfo.ID, int.Parse(id));
                    List<SysModuleNavModel> list = new List<SysModuleNavModel>();
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        SysModuleNavModel model = new SysModuleNavModel();
                        model.id = dt.Rows[i]["menuid"].ToString();
                        model.text = dt.Rows[i]["menuname"].ToString();
                        model.attributes = dt.Rows[i]["linkaddress"].ToString();
                        model.iconCls = dt.Rows[i]["icon"].ToString();
                        if (new MenuBLL().GetMenuList(" AND ParentId= " + model.id).Rows.Count > 0)
                        {
                            model.state = "closed";
                        }
                        else
                        {
                            model.state = "open";
                        }
                        //判断当前是否可以有权限添加
                        if (currentATCheck(model.id))
                            list.Add(model);
                    }
                    return Json(list);
                }
                else
                {
                    return Json("0", JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("0", JsonRequestBehavior.AllowGet);
            }
        }

        private bool currentATCheck(string menuId)
        {
            EUIDemo_AdminLoginModel uInfo = ViewData["Account"] as EUIDemo_AdminLoginModel;
            //客服判断
            if (uInfo.OperationRole == "65")
            {
                //运营客服
                if (uInfo.OperationDepartment.StartsWith("11"))
                {
                    switch (menuId)
                    {
                        //辅导经费划分
                        case "1091":
                            return true;
                        //辅导经费降减
                        case "1092":
                            return true;
                        //辅导经费查询
                        case "1094":
                            return true;
                        //加盟店退单申请
                        case "1096":
                            return true;
                        //冻结店主账号
                        case "1098":
                            return true;
                        //用户手机号变更
                        case "1103":
                            return true;
                        //修改密码
                        case "1105":
                            return true;
                        //合同打印
                        case "1107":
                            return false;
                        //重新打印合同
                        case "1108":
                            return true;
                        default:
                            return true;
                    }
                }
                //市场客服
                else if (uInfo.OperationDepartment.StartsWith("12"))
                {
                    switch (menuId)
                    {
                        //辅导经费划分
                        case "1091":
                            return false;
                        //辅导经费降减
                        case "1092":
                            return false;
                        //辅导经费查询
                        case "1094":
                            return false;
                        //加盟店退单申请
                        case "1096":
                            return true;
                        //冻结店主账号
                        case "1098":
                            return false;
                        //用户手机号变更
                        case "1103":
                            return false;
                        //修改密码
                        case "1105":
                            return false;
                        //合同打印
                        case "1107":
                            return true;
                        //重新打印合同
                        case "1108":
                            return false;
                        default:
                            return true;
                    }

                }
                //辅导中心客服
                else if (uInfo.OperationDepartment.StartsWith("13"))
                {
                    switch (menuId)
                    {
                        //辅导经费划分
                        case "1091":
                            return true;
                        //辅导经费降减
                        case "1092":
                            return true;
                        //辅导经费查询
                        case "1094":
                            return false;
                        //加盟店退单申请
                        case "1096":
                            return true;
                        //冻结店主账号
                        case "1098":
                            return true;
                        //用户手机号变更
                        case "1103":
                            return false;
                        //修改密码
                        case "1105":
                            return false;
                        //合同打印
                        case "1107":
                            return true;
                        //重新打印合同
                        case "1108":
                            return false;
                        default:
                            return true;
                    }

                }

                return true;
            }
            //助理
            else if (uInfo.LoginName == "10005")
            {
                switch (menuId)
                {
                    //比对系统
                    case "1128":
                        return false;
                    //系统设定
                    case "1118":
                        return false;
                    //市场运营客服
                    case "1054":
                        return false;
                    //辅导经费审核
                    case "1093":
                        return false;
                    //市场业绩查询
                    case "1067":
                        return false;
                    //加盟店账号管理
                    case "1095":
                        return false;
                    default:
                        return true;
                }
            }
            else
                return true;
        }
    }

}
