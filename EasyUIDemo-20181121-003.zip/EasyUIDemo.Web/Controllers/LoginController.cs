﻿using EasyUIDemo.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EasyUIDemo.BLL;
using EasyUIDemo.DBUtility;

namespace EasyUIDemo.Web.Controllers
{
    public class LoginController : Controller
    {
        //
        // GET: /Login/
        public ActionResult Index()
        {
            
            return View();
        }


        /// <summary>
        /// 处理登录的信息
        /// </summary>
        /// <param name="userInfo"></param>
        /// <param name="CookieExpires">cookie有效期</param>
        /// <returns></returns>
        public ActionResult CheckUserLogin(EUIDemo_AdminLoginModel userInfo, string CookieExpires)
        {
            try
            {
                if (!(!string.IsNullOrWhiteSpace(userInfo.LoginName) && SqlInjection.IsSafeSqlString(userInfo.LoginName)))
                {
                    return Content("用户名含非法关键词。");
                }

                List<EUIDemo_AdminLoginModel> currentUsers = new EUIDemo_AdminLoginBLL().GetModelList("LoginName='" + userInfo.LoginName + "' and Password='" + Md5.Encrypt(userInfo.Password) + "'");
                EUIDemo_AdminLoginModel currentUser = currentUsers.Count > 0 ? currentUsers[0] : null;

                if (currentUser != null)
                {
                    if (currentUser.Status == 0)
                    {
                        return Content("用户已被禁用，请您联系管理员");
                    }
                    //记录登录cookie
                    //CookiesHelper.SetCookie("UserID", AES.EncryptStr(currentUser.ID.ToString()));
                    Session["UserID"] = currentUser.ID.ToString();
                    //记录用户登录所在IP
                    LoginIpLogEntity logEntity = new LoginIpLogEntity();
                    string ip = Comm.Get_ClientIP();
                    if (string.IsNullOrEmpty(ip))
                    {
                        logEntity.IpAddress = "localhost";
                    }
                    else
                    {
                        logEntity.IpAddress = ip;
                    }
                    logEntity.CreateBy = currentUser.LoginName;
                    logEntity.CreateTime = DateTime.Now;
                    logEntity.UpdateBy = currentUser.LoginName;
                    logEntity.UpdateTime = DateTime.Now;
                    new LoginIpLogBLL().Add(logEntity);

                    return Content("OK");
                }
                else
                {
                    return Content("用户名密码错误，请您检查");
                }
            }
            catch (Exception ex)
            {
                return Content("登录异常," + ex.Message);
            }
        }


        public ActionResult Login()
        {
            try
            {
                //Response.ContentEncoding = System.Text.Encoding.UTF8; //暂时不考虑中文乱码问题
                string account = Request["a"] == null ? "" : Request["a"];//登录账号 明文
                string pass = Request["p"] == null ? "" : Request["p"];//登录密码 密文
                string timestamp = Request["t"] == null ? "" : Request["t"];//时间戳 密文
                string result = Request["r"] == null ? "" : Request["r"];//加密的结果密文

                if (!(!string.IsNullOrWhiteSpace(account) && SqlInjection.IsSafeSqlString(account)))
                {
                    return Content("用户名含非法关键词。");
                }

                if (!(!string.IsNullOrWhiteSpace(pass) && SqlInjection.IsSafeSqlString(pass)))
                {
                    return Content("密码含非法关键词。");
                }

                //时间戳 时间段 判断
                DateTime currentUnix = Comm.GetTime(timestamp).AddMinutes(5);
                DateTime nowTime = DateTime.Now;
                if (currentUnix < nowTime)
                {//超过5分钟 || 未来时间
                    return Content(string.Format("登录超时 T1:{0}  T2:{1}", currentUnix, nowTime));
                    //return Redirect("/Login/Index");
                }

                //（参数名,参数值,参数名,参数值…… key）MD5 大写 
                Dictionary<string, string> dc = new Dictionary<string, string>();
                dc.Add("secretkey", "xinhan2015");
                dc.Add("a", account);
                dc.Add("p", pass);
                dc.Add("t", timestamp);

                dc = Comm.DictonarySort(dc, 1);
                string str_signature = "";
                foreach (KeyValuePair<string, string> kvp in dc)
                {
                    str_signature += "," + kvp.Key + "," + kvp.Value;
                }
                if (str_signature != "") str_signature = str_signature.Substring(1);
                str_signature = Comm.GetMD5(str_signature);

                if (result.ToUpper() != str_signature.ToUpper())
                {
                    //验证失败
                    return Content("异常账号,请正常登录");
                }
                else
                {
                    List<EUIDemo_AdminLoginModel> currentUsers = new EUIDemo_AdminLoginBLL().GetModelList("LoginName='" + account + "' and Password='" + pass + "'");
                    EUIDemo_AdminLoginModel currentUser = currentUsers.Count > 0 ? currentUsers[0] : null;

                    if (currentUser != null)
                    {
                        if (currentUser.Status == 0)
                        {
                            return Content("用户已被禁用，请您联系管理员");
                        }
                        //记录登录cookie
                        //CookiesHelper.SetCookie("UserID", AES.EncryptStr(currentUser.ID.ToString()));
                        Session["UserID"] = currentUser.ID.ToString();
                        //记录用户登录所在IP
                        LoginIpLogEntity logEntity = new LoginIpLogEntity();
                        string ip = Comm.Get_ClientIP();
                        if (string.IsNullOrEmpty(ip))
                        {
                            logEntity.IpAddress = "localhost";
                        }
                        else
                        {
                            logEntity.IpAddress = ip;
                        }
                        logEntity.CreateBy = currentUser.LoginName;
                        logEntity.CreateTime = DateTime.Now;
                        logEntity.UpdateBy = currentUser.LoginName;
                        logEntity.UpdateTime = DateTime.Now;
                        new LoginIpLogBLL().Add(logEntity);

                        return Redirect("/Home/Index");
                    }
                    else
                    {
                        return Content("用户名密码错误，请您检查");
                    }
                }
            }
            catch (Exception ex)
            {
                return Content("登录异常," + ex.Message);
            }
        }

        public ActionResult UserLoginOut()
        {
            //清空cookie
            CookiesHelper.AddCookie("UserID", System.DateTime.Now.AddDays(-1));
            Session["UserID"] = null;
            ViewData["Account"] = null;
            return Content("{\"msg\":\"退出成功！\",\"success\":true}");
        }
    }
}
