﻿using EasyUIDemo.Model;
using System;
using System.Data;
using System.Web.Mvc;
using EasyUIDemo.BLL;
using EasyUIDemo.DBUtility;

namespace EasyUIDemo.Web.Controllers
{
    [EasyUIDemo.Web.App_Start.JudgmentLogin]
    public class CommonController : Controller
    {
        //
        // GET: /Common/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult GetRole()
        {
            try
            {
                EUIDemo_AdminLoginModel uInfo = ViewData["Account"] as EUIDemo_AdminLoginModel;
                if (uInfo == null)
                {
                    return Content("{\"msg\":\"登录超时！\",\"success\":false}");
                }

                //获取数据
                string jsonStr = new EUIDemo_CommonBLL().GetRole();
                if (string.IsNullOrWhiteSpace(jsonStr))
                {
                    return Content("{\"msg\":\"获取失败\",\"success\":false}");
                }
                else
                {
                    return Content(jsonStr);
                }
            }
            catch (Exception ex)
            {
                return Content("{\"msg\":\"获取失败," + ex.Message + "\",\"success\":false}");
            }
        }
        
        /// <summary>
        /// 获取页面操作按钮权限
        /// </summary>
        /// <returns></returns>
        public ActionResult GetUserAuthorize()
        {
            EUIDemo_AdminLoginModel uInfo = ViewData["Account"] as EUIDemo_AdminLoginModel;
            string KeyName = Request["KeyName"];//页面名称关键字
            string KeyCode = Request["KeyCode"];//菜单标识码
            DataTable dt = new ButtonBLL().GetButtonByMenuCodeAndUserId(KeyCode, uInfo.ID);
            return Content(Comm.GetToolBar(dt, KeyName));
        }
        
        #region 获取角色下拉数据
        public ActionResult GetAllRole()
        {
            try
            {
                EUIDemo_AdminLoginModel uInfo = ViewData["Account"] as EUIDemo_AdminLoginModel;
                if (uInfo == null)
                {
                    return Content("{\"msg\":\"登录超时！\",\"success\":false}");
                }

                int fIsWithAll = 1;

                if (!string.IsNullOrEmpty(Request["FIsAll"]) && !EasyUIDemo.DBUtility.SqlInjection.GetString(Request["FIsAll"]))
                {
                    fIsWithAll = Convert.ToInt32(Request["FIsAll"]);
                }

                //获取数据
                string jsonStr = new EUIDemo_CommonBLL().GetAllRole(fIsWithAll);
                if (string.IsNullOrWhiteSpace(jsonStr))
                {
                    return Content("{\"msg\":\"获取失败\",\"success\":false}");
                }
                else
                {
                    return Content(jsonStr);
                }
            }
            catch (Exception ex)
            {
                return Content("{\"msg\":\"获取失败," + ex.Message + "\",\"success\":false}");
            }
        }
        #endregion
    }
}
