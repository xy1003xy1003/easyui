﻿using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using EasyUIDemo.DBUtility;//Please add references
namespace EasyUIDemo.DAL
{
	/// <summary>
	/// 数据访问类:EUIDemo_AdminLogin
	/// </summary>
	public partial class EUIDemo_AdminLoginDAL
	{
		public EUIDemo_AdminLoginDAL()
		{}
		#region  BasicMethod

		/// <summary>
		/// 得到最大ID
		/// </summary>
		public int GetMaxId()
		{
		return DbHelperSQL.GetMaxID("ID", "EUIDemo_AdminLogin"); 
		}

		/// <summary>
		/// 是否存在该记录
		/// </summary>
		public bool Exists(int ID)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) from EUIDemo_AdminLogin");
			strSql.Append(" where ID=@ID");
			SqlParameter[] parameters = {
					new SqlParameter("@ID", SqlDbType.Int,4)
			};
			parameters[0].Value = ID;

			return DbHelperSQL.Exists(strSql.ToString(),parameters);
		}


		/// <summary>
		/// 增加一条数据
		/// </summary>
		public int Add(EasyUIDemo.Model.EUIDemo_AdminLoginModel model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("insert into EUIDemo_AdminLogin(");
			strSql.Append("LoginName,Password,ManagmentDepartment,ManagmentRole,OperationDepartment,OperationRole,RealName,Mobile,Status,Remark,CreateDate,Auditor,AuditTime,UpdateTime)");
			strSql.Append(" values (");
			strSql.Append("@LoginName,@Password,@ManagmentDepartment,@ManagmentRole,@OperationDepartment,@OperationRole,@RealName,@Mobile,@Status,@Remark,@CreateDate,@Auditor,@AuditTime,@UpdateTime)");
			strSql.Append(";select @@IDENTITY");
			SqlParameter[] parameters = {
					new SqlParameter("@LoginName", SqlDbType.NVarChar,20),
					new SqlParameter("@Password", SqlDbType.NVarChar,50),
					new SqlParameter("@ManagmentDepartment", SqlDbType.NVarChar,20),
					new SqlParameter("@ManagmentRole", SqlDbType.NVarChar,50),
					new SqlParameter("@OperationDepartment", SqlDbType.NVarChar,20),
					new SqlParameter("@OperationRole", SqlDbType.NVarChar,50),
					new SqlParameter("@RealName", SqlDbType.NVarChar,20),
					new SqlParameter("@Mobile", SqlDbType.NVarChar,20),
					new SqlParameter("@Status", SqlDbType.Int,4),
					new SqlParameter("@Remark", SqlDbType.NVarChar,200),
					new SqlParameter("@CreateDate", SqlDbType.DateTime),
					new SqlParameter("@Auditor", SqlDbType.NVarChar,20),
					new SqlParameter("@AuditTime", SqlDbType.DateTime),
					new SqlParameter("@UpdateTime", SqlDbType.DateTime)};
			parameters[0].Value = model.LoginName;
			parameters[1].Value = model.Password;
			parameters[2].Value = model.ManagmentDepartment;
			parameters[3].Value = model.ManagmentRole;
			parameters[4].Value = model.OperationDepartment;
			parameters[5].Value = model.OperationRole;
			parameters[6].Value = model.RealName;
			parameters[7].Value = model.Mobile;
			parameters[8].Value = model.Status;
			parameters[9].Value = model.Remark;
			parameters[10].Value = model.CreateDate;
			parameters[11].Value = model.Auditor;
			parameters[12].Value = model.AuditTime;
			parameters[13].Value = model.UpdateTime;

			object obj = DbHelperSQL.GetSingle(strSql.ToString(),parameters);
			if (obj == null)
			{
				return 0;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool Update(EasyUIDemo.Model.EUIDemo_AdminLoginModel model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("update EUIDemo_AdminLogin set ");
			strSql.Append("LoginName=@LoginName,");
			strSql.Append("Password=@Password,");
			strSql.Append("ManagmentDepartment=@ManagmentDepartment,");
			strSql.Append("ManagmentRole=@ManagmentRole,");
			strSql.Append("OperationDepartment=@OperationDepartment,");
			strSql.Append("OperationRole=@OperationRole,");
			strSql.Append("RealName=@RealName,");
			strSql.Append("Mobile=@Mobile,");
			strSql.Append("Status=@Status,");
			strSql.Append("Remark=@Remark,");
			strSql.Append("CreateDate=@CreateDate,");
			strSql.Append("Auditor=@Auditor,");
			strSql.Append("AuditTime=@AuditTime,");
			strSql.Append("UpdateTime=@UpdateTime");
			strSql.Append(" where ID=@ID");
			SqlParameter[] parameters = {
					new SqlParameter("@LoginName", SqlDbType.NVarChar,20),
					new SqlParameter("@Password", SqlDbType.NVarChar,50),
					new SqlParameter("@ManagmentDepartment", SqlDbType.NVarChar,20),
					new SqlParameter("@ManagmentRole", SqlDbType.NVarChar,50),
					new SqlParameter("@OperationDepartment", SqlDbType.NVarChar,20),
					new SqlParameter("@OperationRole", SqlDbType.NVarChar,50),
					new SqlParameter("@RealName", SqlDbType.NVarChar,20),
					new SqlParameter("@Mobile", SqlDbType.NVarChar,20),
					new SqlParameter("@Status", SqlDbType.Int,4),
					new SqlParameter("@Remark", SqlDbType.NVarChar,200),
					new SqlParameter("@CreateDate", SqlDbType.DateTime),
					new SqlParameter("@Auditor", SqlDbType.NVarChar,20),
					new SqlParameter("@AuditTime", SqlDbType.DateTime),
					new SqlParameter("@UpdateTime", SqlDbType.DateTime),
					new SqlParameter("@ID", SqlDbType.Int,4)};
			parameters[0].Value = model.LoginName;
			parameters[1].Value = model.Password;
			parameters[2].Value = model.ManagmentDepartment;
			parameters[3].Value = model.ManagmentRole;
			parameters[4].Value = model.OperationDepartment;
			parameters[5].Value = model.OperationRole;
			parameters[6].Value = model.RealName;
			parameters[7].Value = model.Mobile;
			parameters[8].Value = model.Status;
			parameters[9].Value = model.Remark;
			parameters[10].Value = model.CreateDate;
			parameters[11].Value = model.Auditor;
			parameters[12].Value = model.AuditTime;
			parameters[13].Value = model.UpdateTime;
			parameters[14].Value = model.ID;

			int rows=DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		/// <summary>
		/// 删除一条数据
		/// </summary>
		public bool Delete(int ID)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from EUIDemo_AdminLogin ");
			strSql.Append(" where ID=@ID");
			SqlParameter[] parameters = {
					new SqlParameter("@ID", SqlDbType.Int,4)
			};
			parameters[0].Value = ID;

			int rows=DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		/// <summary>
		/// 批量删除数据
		/// </summary>
		public bool DeleteList(string IDlist )
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from EUIDemo_AdminLogin ");
			strSql.Append(" where ID in ("+IDlist + ")  ");
			int rows=DbHelperSQL.ExecuteSql(strSql.ToString());
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}


		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public EasyUIDemo.Model.EUIDemo_AdminLoginModel GetModel(int ID)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select  top 1 ID,LoginName,Password,ManagmentDepartment,ManagmentRole,OperationDepartment,OperationRole,RealName,Mobile,Status,Remark,CreateDate,Auditor,AuditTime,UpdateTime from EUIDemo_AdminLogin ");
			strSql.Append(" where ID=@ID");
			SqlParameter[] parameters = {
					new SqlParameter("@ID", SqlDbType.Int,4)
			};
			parameters[0].Value = ID;

			EasyUIDemo.Model.EUIDemo_AdminLoginModel model=new EasyUIDemo.Model.EUIDemo_AdminLoginModel();
			DataSet ds=DbHelperSQL.Query(strSql.ToString(),parameters);
			if(ds.Tables[0].Rows.Count>0)
			{
				return DataRowToModel(ds.Tables[0].Rows[0]);
			}
			else
			{
				return null;
			}
		}


		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public EasyUIDemo.Model.EUIDemo_AdminLoginModel DataRowToModel(DataRow row)
		{
			EasyUIDemo.Model.EUIDemo_AdminLoginModel model=new EasyUIDemo.Model.EUIDemo_AdminLoginModel();
			if (row != null)
			{
				if(row["ID"]!=null && row["ID"].ToString()!="")
				{
					model.ID=int.Parse(row["ID"].ToString());
				}
				if(row["LoginName"]!=null)
				{
					model.LoginName=row["LoginName"].ToString();
				}
				if(row["Password"]!=null)
				{
					model.Password=row["Password"].ToString();
				}
				if(row["ManagmentDepartment"]!=null)
				{
					model.ManagmentDepartment=row["ManagmentDepartment"].ToString();
				}
				if(row["ManagmentRole"]!=null)
				{
					model.ManagmentRole=row["ManagmentRole"].ToString();
				}
				if(row["OperationDepartment"]!=null)
				{
					model.OperationDepartment=row["OperationDepartment"].ToString();
				}
				if(row["OperationRole"]!=null)
				{
					model.OperationRole=row["OperationRole"].ToString();
				}
				if(row["RealName"]!=null)
				{
					model.RealName=row["RealName"].ToString();
				}
				if(row["Mobile"]!=null)
				{
					model.Mobile=row["Mobile"].ToString();
				}
				if(row["Status"]!=null && row["Status"].ToString()!="")
				{
					model.Status=int.Parse(row["Status"].ToString());
				}
				if(row["Remark"]!=null)
				{
					model.Remark=row["Remark"].ToString();
				}
				if(row["CreateDate"]!=null && row["CreateDate"].ToString()!="")
				{
					model.CreateDate=DateTime.Parse(row["CreateDate"].ToString());
				}
				if(row["Auditor"]!=null)
				{
					model.Auditor=row["Auditor"].ToString();
				}
				if(row["AuditTime"]!=null && row["AuditTime"].ToString()!="")
				{
					model.AuditTime=DateTime.Parse(row["AuditTime"].ToString());
				}
				if(row["UpdateTime"]!=null && row["UpdateTime"].ToString()!="")
				{
					model.UpdateTime=DateTime.Parse(row["UpdateTime"].ToString());
				}
			}
			return model;
		}

		/// <summary>
		/// 获得数据列表
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select ID,LoginName,Password,ManagmentDepartment,ManagmentRole,OperationDepartment,OperationRole,RealName,Mobile,Status,Remark,CreateDate,Auditor,AuditTime,UpdateTime ");
			strSql.Append(" FROM EUIDemo_AdminLogin ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获得前几行数据
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select ");
			if(Top>0)
			{
				strSql.Append(" top "+Top.ToString());
			}
			strSql.Append(" ID,LoginName,Password,ManagmentDepartment,ManagmentRole,OperationDepartment,OperationRole,RealName,Mobile,Status,Remark,CreateDate,Auditor,AuditTime,UpdateTime ");
			strSql.Append(" FROM EUIDemo_AdminLogin ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			strSql.Append(" order by " + filedOrder);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获取记录总数
		/// </summary>
		public int GetRecordCount(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) FROM EUIDemo_AdminLogin ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			object obj = DbHelperSQL.GetSingle(strSql.ToString());
			if (obj == null)
			{
				return 0;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("SELECT * FROM ( ");
			strSql.Append(" SELECT ROW_NUMBER() OVER (");
			if (!string.IsNullOrEmpty(orderby.Trim()))
			{
				strSql.Append("order by T." + orderby );
			}
			else
			{
				strSql.Append("order by T.ID desc");
			}
			strSql.Append(")AS Row, T.*  from EUIDemo_AdminLogin T ");
			if (!string.IsNullOrEmpty(strWhere.Trim()))
			{
				strSql.Append(" WHERE " + strWhere);
			}
			strSql.Append(" ) TT");
			strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
			return DbHelperSQL.Query(strSql.ToString());
		}

        /*
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetList(int PageSize,int PageIndex,string strWhere)
		{
			SqlParameter[] parameters = {
					new SqlParameter("@tblName", SqlDbType.VarChar, 255),
					new SqlParameter("@fldName", SqlDbType.VarChar, 255),
					new SqlParameter("@PageSize", SqlDbType.Int),
					new SqlParameter("@PageIndex", SqlDbType.Int),
					new SqlParameter("@IsReCount", SqlDbType.Bit),
					new SqlParameter("@OrderType", SqlDbType.Bit),
					new SqlParameter("@strWhere", SqlDbType.VarChar,1000),
					};
			parameters[0].Value = "EUIDemo_AdminLogin";
			parameters[1].Value = "ID";
			parameters[2].Value = PageSize;
			parameters[3].Value = PageIndex;
			parameters[4].Value = 0;
			parameters[5].Value = 0;
			parameters[6].Value = strWhere;	
			return DbHelperSQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
		}*/

        #endregion  BasicMethod
        #region  ExtensionMethod
        #region List
        public DataTable GetUserLoginList(string operater, string loginName, string realName, string roleId, int pageSize, int pageIndex, out int totalRecord)
        {
            SqlParameter[] parameters = {
                        new SqlParameter("@Operator", SqlDbType.NVarChar,20) ,
                        new SqlParameter("@LoginName", SqlDbType.NVarChar, 20),
                        new SqlParameter("@RealName", SqlDbType.NVarChar, 20),
                        new SqlParameter("@RoleId", SqlDbType.NVarChar, 20),
                        new SqlParameter("@PageSize", SqlDbType.Int) ,
                        new SqlParameter("@PageIndex", SqlDbType.Int),
                        new SqlParameter("@TotalRecord", SqlDbType.Int)
            };

            parameters[0].Value = operater;
            parameters[1].Value = loginName;
            parameters[2].Value = realName;
            parameters[3].Value = roleId;
            parameters[4].Value = pageSize;
            parameters[5].Value = pageIndex;
            parameters[6].Direction = ParameterDirection.Output;

            DataSet ds = SqlHelper.GetDataSetByRunProcedure("proc_EUIDemo_ht_adminlogin_query", parameters, out totalRecord);
            if (ds != null && ds.Tables.Count >= 1)
            {
                return ds.Tables[0];
            }
            else
            {
                return null;
            }
        }
        #endregion

        #region Add
        public int AddOperation(string operater, string loginName, string password, string roleName, string realName,
            string managmentDepartment, string mobile, string remark)
        {
            SqlParameter[] parameters = {
                        new SqlParameter("@LoginName", SqlDbType.NVarChar,20),
                        new SqlParameter("@Password", SqlDbType.NVarChar,50),
                        new SqlParameter("@ManagmentDepartment", SqlDbType.NVarChar,20),
                        new SqlParameter("@ManagmentRole", SqlDbType.NVarChar,50),
                        new SqlParameter("@RealName", SqlDbType.NVarChar,20),
                        new SqlParameter("@Mobile", SqlDbType.NVarChar,20),
                        new SqlParameter("@Remark", SqlDbType.NVarChar,200),
                        new SqlParameter("@Operator", SqlDbType.NVarChar,20)
            };
            parameters[0].Value = loginName;
            parameters[1].Value = password;
            parameters[2].Value = managmentDepartment;
            parameters[3].Value = roleName;
            parameters[4].Value = realName;
            parameters[5].Value = mobile;
            parameters[6].Value = remark;
            parameters[7].Value = operater;

            int count = SqlHelper.RunProcedureReturnValue("proc_EUIDemo_ht_adminlogin_add", parameters);
            return count;
        }
        #endregion

        #region Edit
        public int EditOperation(string operater, string id, string loginName, string password, string roleName, string realName,
            string managmentDepartment, string mobile, string remark)
        {
            SqlParameter[] parameters = {
                        new SqlParameter("@ID", SqlDbType.NVarChar,20),
                        new SqlParameter("@LoginName", SqlDbType.NVarChar,20),
                        new SqlParameter("@Password", SqlDbType.NVarChar,50),
                        new SqlParameter("@ManagmentDepartment", SqlDbType.NVarChar,20),
                        new SqlParameter("@ManagmentRole", SqlDbType.NVarChar,50),
                        new SqlParameter("@RealName", SqlDbType.NVarChar,20),
                        new SqlParameter("@Mobile", SqlDbType.NVarChar,20),
                        new SqlParameter("@Remark", SqlDbType.NVarChar,200),
                        new SqlParameter("@Operator", SqlDbType.NVarChar,20)
            };
            parameters[0].Value = id;
            parameters[1].Value = loginName;
            parameters[2].Value = password;
            parameters[3].Value = managmentDepartment;
            parameters[4].Value = roleName;
            parameters[5].Value = realName;
            parameters[6].Value = mobile;
            parameters[7].Value = remark;
            parameters[8].Value = operater;

            int count = SqlHelper.RunProcedureReturnValue("proc_EUIDemo_ht_adminlogin_edit", parameters);
            return count;
        }
        #endregion
        #endregion  ExtensionMethod
    }
}

