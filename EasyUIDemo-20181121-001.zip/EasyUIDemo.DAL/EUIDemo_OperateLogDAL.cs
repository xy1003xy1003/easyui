﻿using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using EasyUIDemo.DBUtility;

namespace EasyUIDemo.DAL
{
    /// <summary>
    /// 数据访问类:EUIDemo_OperateLog
    /// </summary>
    public partial class EUIDemo_OperateLogDAL
    {
        public EUIDemo_OperateLogDAL()
        { }
        #region  BasicMethod



        /// <summary>
        /// 增加一条数据
        /// </summary>
        public int Add(Model.EUIDemo_OperateLogModel model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("insert into EUIDemo_OperateLog(");
            strSql.Append("OperateDate,OperateType,OperateName,OperateContent,OperateIP,OperateID,OperateAccount,OperateAmount,OperateRemark,UpdateTime)");
            strSql.Append(" values (");
            strSql.Append("@OperateDate,@OperateType,@OperateName,@OperateContent,@OperateIP,@OperateID,@OperateAccount,@OperateAmount,@OperateRemark,@UpdateTime)");
            strSql.Append(";select @@IDENTITY");
            SqlParameter[] parameters = {
                    new SqlParameter("@OperateDate", SqlDbType.DateTime),
                    new SqlParameter("@OperateType", SqlDbType.NVarChar,20),
                    new SqlParameter("@OperateName", SqlDbType.NVarChar,20),
                    new SqlParameter("@OperateContent", SqlDbType.NVarChar,200),
                    new SqlParameter("@OperateIP", SqlDbType.NVarChar,20),
                    new SqlParameter("@OperateID", SqlDbType.Int,4),
                    new SqlParameter("@OperateAccount", SqlDbType.NVarChar,20),
                    new SqlParameter("@OperateAmount", SqlDbType.Decimal,9),
                    new SqlParameter("@OperateRemark", SqlDbType.NVarChar,2000),
                    new SqlParameter("@UpdateTime", SqlDbType.DateTime)};
            parameters[0].Value = model.OperateDate;
            parameters[1].Value = model.OperateType;
            parameters[2].Value = model.OperateName;
            parameters[3].Value = model.OperateContent;
            parameters[4].Value = model.OperateIP;
            parameters[5].Value = model.OperateID;
            parameters[6].Value = model.OperateAccount;
            parameters[7].Value = model.OperateAmount;
            parameters[8].Value = model.OperateRemark;
            parameters[9].Value = model.UpdateTime;

            object obj = DbHelperSQL.GetSingle(strSql.ToString(), parameters);
            if (obj == null)
            {
                return 0;
            }
            else
            {
                return Convert.ToInt32(obj);
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool Update(Model.EUIDemo_OperateLogModel model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update EUIDemo_OperateLog set ");
            strSql.Append("OperateDate=@OperateDate,");
            strSql.Append("OperateType=@OperateType,");
            strSql.Append("OperateName=@OperateName,");
            strSql.Append("OperateContent=@OperateContent,");
            strSql.Append("OperateIP=@OperateIP,");
            strSql.Append("OperateID=@OperateID,");
            strSql.Append("OperateAccount=@OperateAccount,");
            strSql.Append("OperateAmount=@OperateAmount,");
            strSql.Append("OperateRemark=@OperateRemark,");
            strSql.Append("UpdateTime=@UpdateTime");
            strSql.Append(" where ID=@ID");
            SqlParameter[] parameters = {
                    new SqlParameter("@OperateDate", SqlDbType.DateTime),
                    new SqlParameter("@OperateType", SqlDbType.NVarChar,20),
                    new SqlParameter("@OperateName", SqlDbType.NVarChar,20),
                    new SqlParameter("@OperateContent", SqlDbType.NVarChar,200),
                    new SqlParameter("@OperateIP", SqlDbType.NVarChar,20),
                    new SqlParameter("@OperateID", SqlDbType.Int,4),
                    new SqlParameter("@OperateAccount", SqlDbType.NVarChar,20),
                    new SqlParameter("@OperateAmount", SqlDbType.Decimal,9),
                    new SqlParameter("@OperateRemark", SqlDbType.NVarChar,2000),
                    new SqlParameter("@UpdateTime", SqlDbType.DateTime),
                    new SqlParameter("@ID", SqlDbType.Int,4)};
            parameters[0].Value = model.OperateDate;
            parameters[1].Value = model.OperateType;
            parameters[2].Value = model.OperateName;
            parameters[3].Value = model.OperateContent;
            parameters[4].Value = model.OperateIP;
            parameters[5].Value = model.OperateID;
            parameters[6].Value = model.OperateAccount;
            parameters[7].Value = model.OperateAmount;
            parameters[8].Value = model.OperateRemark;
            parameters[9].Value = model.UpdateTime;
            parameters[10].Value = model.ID;

            int rows = DbHelperSQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 删除一条数据
        /// </summary>
        public bool Delete(int ID)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from EUIDemo_OperateLog ");
            strSql.Append(" where ID=@ID");
            SqlParameter[] parameters = {
                    new SqlParameter("@ID", SqlDbType.Int,4)
            };
            parameters[0].Value = ID;

            int rows = DbHelperSQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 批量删除数据
        /// </summary>
        public bool DeleteList(string IDlist)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from EUIDemo_OperateLog ");
            strSql.Append(" where ID in (" + IDlist + ")  ");
            int rows = DbHelperSQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Model.EUIDemo_OperateLogModel GetModel(int ID)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("select  top 1 ID,OperateDate,OperateType,OperateName,OperateContent,OperateIP,OperateID,OperateAccount,OperateAmount,OperateRemark,UpdateTime from EUIDemo_OperateLog ");
            strSql.Append(" where ID=@ID");
            SqlParameter[] parameters = {
                    new SqlParameter("@ID", SqlDbType.Int,4)
            };
            parameters[0].Value = ID;

            Model.EUIDemo_OperateLogModel model = new Model.EUIDemo_OperateLogModel();
            DataSet ds = DbHelperSQL.Query(strSql.ToString(), parameters);
            if (ds.Tables[0].Rows.Count > 0)
            {
                return DataRowToModel(ds.Tables[0].Rows[0]);
            }
            else
            {
                return null;
            }
        }


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Model.EUIDemo_OperateLogModel DataRowToModel(DataRow row)
        {
            Model.EUIDemo_OperateLogModel model = new Model.EUIDemo_OperateLogModel();
            if (row != null)
            {
                if (row["ID"] != null && row["ID"].ToString() != "")
                {
                    model.ID = int.Parse(row["ID"].ToString());
                }
                if (row["OperateDate"] != null && row["OperateDate"].ToString() != "")
                {
                    model.OperateDate = DateTime.Parse(row["OperateDate"].ToString());
                }
                if (row["OperateType"] != null)
                {
                    model.OperateType = row["OperateType"].ToString();
                }
                if (row["OperateName"] != null)
                {
                    model.OperateName = row["OperateName"].ToString();
                }
                if (row["OperateContent"] != null)
                {
                    model.OperateContent = row["OperateContent"].ToString();
                }
                if (row["OperateIP"] != null)
                {
                    model.OperateIP = row["OperateIP"].ToString();
                }
                if (row["OperateID"] != null && row["OperateID"].ToString() != "")
                {
                    model.OperateID = int.Parse(row["OperateID"].ToString());
                }
                if (row["OperateAccount"] != null)
                {
                    model.OperateAccount = row["OperateAccount"].ToString();
                }
                if (row["OperateAmount"] != null && row["OperateAmount"].ToString() != "")
                {
                    model.OperateAmount = decimal.Parse(row["OperateAmount"].ToString());
                }
                if (row["OperateRemark"] != null)
                {
                    model.OperateRemark = row["OperateRemark"].ToString();
                }
                if (row["UpdateTime"] != null && row["UpdateTime"].ToString() != "")
                {
                    model.UpdateTime = DateTime.Parse(row["UpdateTime"].ToString());
                }
            }
            return model;
        }

        /// <summary>
        /// 获得数据列表
        /// </summary>
        public DataSet GetList(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select ID,OperateDate,OperateType,OperateName,OperateContent,OperateIP,OperateID,OperateAccount,OperateAmount,OperateRemark,UpdateTime ");
            strSql.Append(" FROM EUIDemo_OperateLog ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            return DbHelperSQL.Query(strSql.ToString());
        }

        /// <summary>
        /// 获得前几行数据
        /// </summary>
        public DataSet GetList(int Top, string strWhere, string filedOrder)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select ");
            if (Top > 0)
            {
                strSql.Append(" top " + Top.ToString());
            }
            strSql.Append(" ID,OperateDate,OperateType,OperateName,OperateContent,OperateIP,OperateID,OperateAccount,OperateAmount,OperateRemark,UpdateTime ");
            strSql.Append(" FROM EUIDemo_OperateLog ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            strSql.Append(" order by " + filedOrder);
            return DbHelperSQL.Query(strSql.ToString());
        }

        /// <summary>
        /// 获取记录总数
        /// </summary>
        public int GetRecordCount(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) FROM EUIDemo_OperateLog ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            object obj = DbHelperSQL.GetSingle(strSql.ToString());
            if (obj == null)
            {
                return 0;
            }
            else
            {
                return Convert.ToInt32(obj);
            }
        }
        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("SELECT * FROM ( ");
            strSql.Append(" SELECT ROW_NUMBER() OVER (");
            if (!string.IsNullOrEmpty(orderby.Trim()))
            {
                strSql.Append("order by T." + orderby);
            }
            else
            {
                strSql.Append("order by T.ID desc");
            }
            strSql.Append(")AS Row, T.*  from EUIDemo_OperateLog T ");
            if (!string.IsNullOrEmpty(strWhere.Trim()))
            {
                strSql.Append(" WHERE " + strWhere);
            }
            strSql.Append(" ) TT");
            strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
            return DbHelperSQL.Query(strSql.ToString());
        }

        /*
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetList(int PageSize,int PageIndex,string strWhere)
		{
			SqlParameter[] parameters = {
					new SqlParameter("@tblName", SqlDbType.VarChar, 255),
					new SqlParameter("@fldName", SqlDbType.VarChar, 255),
					new SqlParameter("@PageSize", SqlDbType.Int),
					new SqlParameter("@PageIndex", SqlDbType.Int),
					new SqlParameter("@IsReCount", SqlDbType.Bit),
					new SqlParameter("@OrderType", SqlDbType.Bit),
					new SqlParameter("@strWhere", SqlDbType.VarChar,1000),
					};
			parameters[0].Value = "EUIDemo_OperateLog";
			parameters[1].Value = "ID";
			parameters[2].Value = PageSize;
			parameters[3].Value = PageIndex;
			parameters[4].Value = 0;
			parameters[5].Value = 0;
			parameters[6].Value = strWhere;	
			return DbHelperSQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
		}*/

        #endregion  BasicMethod
        #region  ExtensionMethod

        #endregion  ExtensionMethod
    }
}

