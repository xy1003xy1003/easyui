﻿using EasyUIDemo.Model;
using EasyUIDemo.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using EasyUIDemo.DBUtility;

namespace EasyUIDemo.DAL
{
    public class MenuButtonDAL
    {
        /// <summary>
        /// 分配 菜单按钮 执行事务 先批量删除 再批量插入
        /// </summary>
        public bool SaveMenuButton(string menuid, string buttonids)
        {
            List<string> list = new List<string>();
            list.Add("delete from EUIDemo_tbMenuButton where MenuId =" + menuid);
            foreach (string btnid in buttonids.TrimStart(',').TrimEnd(',').Split(','))
            {
                if (btnid != "0")
                {
                    list.Add("INSERT INTO EUIDemo_tbMenuButton(MenuId,ButtonId)VALUES(" + menuid + "," + btnid + ")");
                }
            }
            try
            {
                if (SqlHelper.ExecuteNonQuery(SqlHelper.connStr, list) > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }


        /// <summary>
        /// 根据菜单id查询所有分配的按钮
        /// </summary>
        public DataTable GetButtonByMenuId(int menuId)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append(" SELECT Id,MenuId,ButtonId FROM EUIDemo_tbMenuButton ");
            strSql.Append(" where MenuId=@MenuId ");
            SqlParameter[] paras = { 
                                   new SqlParameter("@MenuId",SqlDbType.Int)
                                   };
            paras[0].Value = menuId;
            return SqlHelper.GetDataTable(SqlHelper.connStr, CommandType.Text, strSql.ToString(), paras);
        }

        /// <summary>
        /// 分配 菜单按钮 执行事务 先批量删除 再批量插入
        /// </summary>
        public bool DelRoleMenuButtonByRoleId(int RoleId)
        {
            List<string> list = new List<string>();
            list.Add("delete from EUIDemo_tbRoleMenuButton where RoleId =" + RoleId);
            try
            {
                if (SqlHelper.ExecuteNonQuery(SqlHelper.connStr, list) > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }
    }
}
