﻿using EasyUIDemo.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using EasyUIDemo.DBUtility;

namespace EasyUIDemo.DAL
{
    public class DalCommonDAL
    {
        /// <summary>
        ///  存储过程分页获取数据
        /// </summary>
        /// <param name="tableName">表名</param>
        /// <param name="selectFields">需要查询的字段 如果是所有那么就是为 *</param>
        /// <param name="andWhere"> 查询条件比如 1=1 </param>
        /// <param name="orderByFields">排序字段 比如ID </param>
        /// <param name="pageIndex">页码</param>
        /// <param name="pageSize">条目</param>
        /// <param name="totalRows">返回的总条目数</param>
        /// <param name="orderByType">排序方式 desc或者asc</param>
        /// <param name="getSelectSql">返回的sql</param>
        /// <returns></returns>
        public DataTable GetPagedData(string tableName, string selectFields, string andWhere, string orderByFields, int pageIndex, int pageSize, out int totalCount, string orderByType, out string getSelectSql)
        {
            DataTable dt = new DataTable();
            totalCount = 0;
            getSelectSql = string.Empty;
            try
            {
                if (string.IsNullOrEmpty(tableName) || string.IsNullOrEmpty(orderByFields))
                {
                    return dt;
                }
                pageIndex = pageIndex > 0 ? pageIndex : 1;
                pageSize = pageSize > 0 ? pageSize : 1;
                orderByType = ((orderByType.ToLower().Trim() == "asc") || (orderByType.ToLower().Trim() == "desc")) ? orderByType : "asc";
                selectFields = string.IsNullOrEmpty(selectFields) ? "*" : selectFields;

                SqlParameter[] parameters = {
                    new SqlParameter("@tableName", SqlDbType.NVarChar,200),
                     new SqlParameter("@selectFields", SqlDbType.NVarChar,1000),
                      new SqlParameter("@andWhere", SqlDbType.NVarChar,2000),
                       new SqlParameter("@orderByFields", SqlDbType.NVarChar,100),
                       new SqlParameter("@pageIndex", SqlDbType.Int,4),
                       new SqlParameter("@pageSize", SqlDbType.Int,4),
                       new SqlParameter("@totalCount", SqlDbType.Int,4),
                       new SqlParameter("@orderType", SqlDbType.NVarChar,5),
                       new SqlParameter("@sql", SqlDbType.NVarChar,4000)
                };
                parameters[0].Value = tableName;
                parameters[1].Value = selectFields;
                parameters[2].Value = andWhere;
                parameters[3].Value = orderByFields;
                parameters[4].Value = pageIndex;
                parameters[5].Value = pageSize;
                parameters[6].Direction = ParameterDirection.Output;
                parameters[7].Value = orderByType;
                parameters[8].Direction = ParameterDirection.Output;

                DataSet ds = SqlHelper.RunProcedureByPage("proc_zka_shengft_page_query", parameters, out totalCount, out getSelectSql);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dt = ds.Tables[0];
                }
                else
                {
                    dt = null;
                }
            }
            catch (System.Data.SqlClient.SqlException e)
            {
                throw e;
                //dt = null;
                //ESHD.Command.LsgLog.AddError(e, tableName + "selectFields");
            }
            return dt;
        }
        
        #region 添加-ZKA_OperateLog表记录
        /// <summary>
        /// 添加-ZKA_OperateLog表记录
        /// </summary>
        /// <param name="OperateType">操作类型</param>
        /// <param name="OperateName">操作名称</param>
        /// <param name="OperateContent">操作内容</param>
        /// <param name="OperateIP">操作IP</param>
        /// <param name="OperateID">操作ID</param>
        /// <param name="OperateAccount">操作账号</param>
        /// <param name="OperateAmount">操作金额</param>
        /// <param name="OperateRemark">操作备注</param>
        /// <returns></returns>
        public int AddOperateLog(string OperateType, string OperateName, string OperateContent, string OperateIP, int OperateID, string OperateAccount, decimal OperateAmount, string OperateRemark)
        {
            SqlParameter[] parameters = {
                        new SqlParameter("@OperateType", SqlDbType.NVarChar,20) ,
                        new SqlParameter("@OperateName", SqlDbType.NVarChar,20) ,
                        new SqlParameter("@OperateContent", SqlDbType.NVarChar,200) ,
                        new SqlParameter("@OperateIP", SqlDbType.NVarChar,20),
                        new SqlParameter("@OperateID", SqlDbType.Int),
                        new SqlParameter("@OperateAccount", SqlDbType.NVarChar,20),
                        new SqlParameter("@OperateAmount", SqlDbType.Decimal),
                        new SqlParameter("@OperateRemark", SqlDbType.NVarChar,2000)
                };
            parameters[0].Value = OperateType;
            parameters[1].Value = OperateName;
            parameters[2].Value = OperateContent;
            parameters[3].Value = OperateIP;
            parameters[4].Value = OperateID;
            parameters[5].Value = OperateAccount;
            parameters[6].Value = OperateAmount;
            parameters[7].Value = OperateRemark;
            int count = SqlHelper.RunProcedureReturnValue("proc_zka_ht_operatelog_add", parameters);
            return count;
        }

        public int EditMemberPass(int UpdateType, string useraccount, string MobileOld, string MobileNew, string PasswordNew, string remark)
        {
            SqlParameter[] parameters = {
                        new SqlParameter("@UpdateType", SqlDbType.Int) ,
                        new SqlParameter("@MemberAccount", SqlDbType.NVarChar,20) ,
                        new SqlParameter("@MobileOld", SqlDbType.NVarChar,20) ,
                        new SqlParameter("@MobileNew", SqlDbType.NVarChar,20),
                        new SqlParameter("@PasswordNew", SqlDbType.NVarChar,50),
                        new SqlParameter("@UpdateRemark", SqlDbType.NVarChar,200)
            };
            parameters[0].Value = UpdateType;
            parameters[1].Value = useraccount;
            parameters[2].Value = MobileOld;
            parameters[3].Value = MobileNew;
            parameters[4].Value = PasswordNew;
            parameters[5].Value = remark;
            int count = SqlHelper.RunProcedureReturnValue("proc_zka_ht_account_msg_update", parameters);
            return count;
        }

        #endregion
        
    }
}
