﻿using EasyUIDemo.DBUtility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace EasyUIDemo.DAL
{
    public class EUIDemo_CommonDAL
    {
        public DataTable GetTipMsg(int opID)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append(string.Format("SELECT ReturnMsg FROM ERROR_RETURN_CODE WHERE ReturnCode = '{0}'", opID));
            return SqlHelper.GetDataTable(SqlHelper.connStr, CommandType.Text, strSql.ToString(), null);
        }
        
        public DataTable GetRole()
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append(" SELECT Id AS id, RoleName AS text FROM EUIDemo_tbRole WHERE Id > 1 ");
            return SqlHelper.GetDataTable(SqlHelper.connStr, CommandType.Text, strSql.ToString(), null);
        }
        
        public DataTable GetAllRole()
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append(" SELECT Id AS id, RoleName AS text FROM EUIDemo_tbRole WHERE Id > 1 ");
            return SqlHelper.GetDataTable(SqlHelper.connStr, CommandType.Text, strSql.ToString(), null);
        }
        
    }
}
