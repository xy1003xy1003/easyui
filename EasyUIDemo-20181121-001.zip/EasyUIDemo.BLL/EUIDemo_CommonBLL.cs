﻿using EasyUIDemo.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace EasyUIDemo.BLL
{
    public partial class EUIDemo_CommonBLL
    {
        private readonly EUIDemo_CommonDAL dal = new EUIDemo_CommonDAL();

        public EUIDemo_CommonBLL()
        { }
        
        
        public string GetTip(int opID, string optype)
        {
            string msg = string.Format("未知错误:{0}", opID);

            DataTable dt = dal.GetTipMsg(opID);
            if (dt != null && dt.Rows != null && dt.Rows.Count > 0)
            {
                msg = string.Format("{0}({1})", dt.Rows[0][0], opID);
            }

            return msg;
        }
        
        public string GetRole()
        {
            DataTable dt = null;
            try
            {
                dt = dal.GetRole();
                DataView dv = dt.DefaultView;
                dv.Sort = " id asc";
                dt = dv.ToTable();
            }
            catch (Exception ex)
            {
                dt = null;
            }
            return Newtonsoft.Json.JsonConvert.SerializeObject(dt);
        }

        public string GetAllRole(int isWithAll)
        {
            DataTable dt = null;
            try
            {
                dt = dal.GetAllRole();
                if (isWithAll == 1)
                {
                    DataRow dr = dt.NewRow();
                    dr["id"] = 0;
                    dr["text"] = "所有";
                    dt.Rows.Add(dr);
                }
                DataView dv = dt.DefaultView;
                dv.Sort = " id asc";
                dt = dv.ToTable();
            }
            catch (Exception ex)
            {
                dt = null;
            }
            return Newtonsoft.Json.JsonConvert.SerializeObject(dt);
        }
        
    }
}
