﻿using EasyUIDemo.DAL;
using EasyUIDemo.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
//using Newtonsoft.Json.Converters;
using EasyUIDemo.DBUtility;

namespace EasyUIDemo.BLL
{
    public class DalCommonBLL
    {
        private readonly DalCommonDAL dal = new DalCommonDAL();

        public int AddOperateLog(EUIDemo_OperateLogModel logModel)
        {
            return dal.AddOperateLog(logModel.OperateType, logModel.OperateName, logModel.OperateContent, logModel.OperateIP, logModel.OperateID, logModel.OperateAccount, logModel.OperateAmount, logModel.OperateRemark);
        }

        /// <summary>
        ///  存储过程分页获取数据
        /// </summary>
        /// <param name="tableName">表名</param>
        /// <param name="selectFields">需要查询的字段 如果是所有那么就是为 *</param>
        /// <param name="andWhere"> 查询条件比如 and  id>1 </param>
        /// <param name="orderByFields">排序字段 比如ID </param>
        /// <param name="pageIndex">页码</param>
        /// <param name="pageSize">条目</param>
        /// <param name="totalRows">返回的总条目数</param>
        /// <param name="orderByType">排序方式 desc或者asc</param>
        /// <param name="getSelectSql">返回的sql</param>
        /// <returns></returns>
        public DataTable GetPagedData(string tableName, string selectFields, string andWhere, string orderByFields, int pageIndex, int pageSize, out int totalRows, string orderByType, out string getSelectSql)
        {

            return dal.GetPagedData(tableName, selectFields, andWhere, orderByFields, pageIndex, pageSize, out totalRows, orderByType, out getSelectSql);
        }
        
    }
}
