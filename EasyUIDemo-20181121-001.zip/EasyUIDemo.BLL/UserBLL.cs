﻿using EasyUIDemo.DAL;
using EasyUIDemo.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using EasyUIDemo.DBUtility;

namespace EasyUIDemo.BLL
{
    /// <summary>
    /// 用户（BLL）
    /// </summary>
    public class UserBLL
    {
        private readonly UserDAL dal = new UserDAL();

        /// <summary>
        /// 根据用户id获取用户
        /// </summary>
        public UserEntity GetUserByUserId(string userId)
        {
            return dal.GetUserByUserId(userId);
        }

        /// <summary>
        /// 根据id获取用户
        /// </summary>
        public UserEntity GetUserById(string id)
        {
            return dal.GetUserById(id);
        }

        /// <summary>
        /// 首次登陆强制修改密码
        /// </summary>
        public bool InitUserPwd(UserEntity user)
        {
            return dal.InitUserPwd(user);
        }

        /// <summary>
        /// 修改密码
        /// </summary>
        public bool ChangePwd(UserEntity user)
        {
            return dal.ChangePwd(user);
        }

        /// <summary>
        /// 用户登录
        /// </summary>
        public UserEntity UserLogin(string loginId, string loginPwd)
        {
            return dal.UserLogin(loginId, loginPwd);
        }

        /// <summary>
        /// 根据用户id判断用户是否可用
        /// </summary>
        public UserEntity CheckLoginByUserId(string userId)
        {
            return dal.CheckLoginByUserId(userId);
        }

        /// <summary>
        /// 获取分页数据
        /// </summary>
        /// <param name="tableName">表名</param>
        /// <param name="columns">要取的列名（逗号分开）</param>
        /// <param name="order">排序</param>
        /// <param name="pageSize">每页大小</param>
        /// <param name="pageIndex">当前页</param>
        /// <param name="where">查询条件</param>
        /// <param name="totalCount">总记录数</param>
        public string GetPager(string tableName, string columns, string order, int pageSize, int pageIndex, string where, out int totalCount)
        {
            DataTable dt = EasyUIDemo.DBUtility.SqlPagerHelper.GetPager(tableName, columns, order, pageSize, pageIndex, where, out totalCount);
            dt.Columns.Add(new DataColumn("UserRoleId"));
            dt.Columns.Add(new DataColumn("UserRole"));
            dt.Columns.Add(new DataColumn("UserDepartmentId"));
            dt.Columns.Add(new DataColumn("UserDepartment"));
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                DataTable dtrole = new RoleBLL().GetRoleByUserId(Convert.ToInt32(dt.Rows[i]["ID"]));
                DataTable dtdepartment = new DepartmentBLL().GetDepartmentByUserId(Convert.ToInt32(dt.Rows[i]["ID"]));
                dt.Rows[i]["UserRoleId"] = EasyUIDemo.DBUtility.JsonHelper.ColumnToJson(dtrole, 0);
                dt.Rows[i]["UserRole"] = EasyUIDemo.DBUtility.JsonHelper.ColumnToJson(dtrole, 1);
                dt.Rows[i]["UserDepartmentId"] = EasyUIDemo.DBUtility.JsonHelper.ColumnToJson(dtdepartment, 0);
                dt.Rows[i]["UserDepartment"] = EasyUIDemo.DBUtility.JsonHelper.ColumnToJson(dtdepartment, 1);
            }
            return EasyUIDemo.DBUtility.JsonHelper.ToJson(dt);
        }

        /// <summary>
        /// 添加用户
        /// </summary>
        public int AddUser(UserEntity user)
        {
            UserEntity userCompare = dal.GetUserByUserId(user.AccountName);
            if (userCompare != null)
            {
                throw new Exception("已经存在此用户！");
            }
            return dal.AddUser(user);
        }

        /// <summary>
        /// 删除用户（可批量删除，删除用户同时删除对应的权限和所处的部门）
        /// </summary>
        public bool DeleteUser(string idList)
        {
            return dal.DeleteUser(idList);
        }

        /// <summary>
        /// 修改用户
        /// </summary>
        public bool EditUser(UserEntity user, string originalName)
        {
            if (user.AccountName != originalName && dal.GetUserByUserId(user.AccountName) != null)
            {
                throw new Exception("已经存在此用户！");
            }
            return dal.EditUser(user);
        }

        /// <summary>
        /// 获取用户信息（“我的信息”）
        /// </summary>
        public string GetUserInfo(int userId)
        {
            DataTable dt = dal.GetUserInfo(userId);

            if (dt.Rows.Count > 1)
            {
                DataView dataView = new DataView(dt);
                DataTable dtDistinctRoleName = dataView.ToTable(true, new string[] { "RoleName" });
                DataTable dtDistinctDepartmentName = dataView.ToTable(true, new string[] { "DepartmentName" });

                string roleNames = "";
                string departmentNames = "";
                for (int i = 0; i < dtDistinctRoleName.Rows.Count; i++)
                {
                    roleNames += dtDistinctRoleName.Rows[i]["RoleName"] + ",";
                }
                for (int j = 0; j < dtDistinctDepartmentName.Rows.Count; j++)
                {
                    departmentNames += dtDistinctDepartmentName.Rows[j]["DepartmentName"] + ",";
                }

                DataTable dtNew = dt.Clone();

                DataRow rowNew = dtNew.NewRow();
                rowNew["UserId"] = dt.Rows[0]["UserId"];
                rowNew["UserName"] = dt.Rows[0]["UserName"];
                rowNew["AddDate"] = dt.Rows[0]["AddDate"];
                rowNew["RoleName"] = roleNames.Trim(',');
                rowNew["DepartmentName"] = departmentNames.Trim(',');
                dtNew.Rows.Add(rowNew);

                return JsonHelper.ToJson(dtNew);
            }
            else
            {
                return JsonHelper.ToJson(dt);
            }
        }

        public bool sysmaintenanceCheck()
        {
            return dal.sysmaintenanceCheck();
        }


        #region 扩展 - 登录用户

        public string GetLoginUserList(string operater, string userAcc, int pageSize, int pageIndex, out int totalRecord)
        {
            DataTable dt = dal.GetLoginUserList(operater, userAcc, pageSize, pageIndex, out totalRecord);
            if (dt != null)
            {
                return Newtonsoft.Json.JsonConvert.SerializeObject(dt);
            }
            else
            {
                return string.Empty;
            }
        }

        public int AddLoginUser(string operater, string userAcc, string userPass, string userRole, string userMobile, string realName, string remark)
        {
            return dal.AddLoginUser(operater, userAcc, userPass, userRole, userMobile, realName, remark);
        }

        public bool DeleteLoginUser(string idList)
        {
            return dal.DeleteLoginUser(idList);
        }

        #endregion
    }
}
